"""端侧 Pyodide 桥：复用正式服的 table / engine / profiles，不跑 HTTP 服务。

JS 侧提供 __manorSend(text) 把服务端消息推回页面；
页面通过 local_bridge.handle(text) 发消息，local_bridge.api(path) 取 REST 数据。
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from datetime import datetime, timezone
from urllib.parse import parse_qs, unquote, urlparse

_READY = False
_CLIENT = None
_TABLE = None
_PROFILES = None
_META = None
_HISTORY = None
_LAN_URL = "http://127.0.0.1/"


def _emit(payload) -> None:
    try:
        from js import __manorSend
        __manorSend(json.dumps(payload, ensure_ascii=False))
    except Exception:
        pass


def init(data_dir: str) -> None:
    global _READY, _TABLE, _PROFILES, _META, _HISTORY
    if _READY:
        return
    os.environ["DOUDIZHU_DATA_DIR"] = data_dir
    os.makedirs(data_dir, exist_ok=True)
    if "/home/pyodide" not in sys.path:
        sys.path.insert(0, "/home/pyodide")

    # Pyodide 没有线程；AI 很小，直接同步算，await 语义保持不变。
    async def _to_thread(func, *args, **kwargs):
        return func(*args, **kwargs)

    asyncio.to_thread = _to_thread

    from app import meta as meta_mod
    from app import history as history_mod

    # 先用 NumPy 版 DouZero 顶替正式服的 torch agent，再导入 table/bidding。
    try:
        import app.ai.agent as agent_mod
        from local_ai import NumpyDouZeroAI
        local_ai = NumpyDouZeroAI("/models")
        if local_ai.available:
            agent_mod.ai = local_ai
            print("local DouZero ready", flush=True)
        else:
            print("local DouZero unavailable: " + local_ai.error, flush=True)
    except Exception:
        import traceback
        traceback.print_exc()

    from app.table import table as table_obj
    from app.profiles import profiles as profiles_obj

    _TABLE = table_obj
    _PROFILES = profiles_obj
    _META = meta_mod
    _HISTORY = history_mod
    _READY = True
    try:
        from app.ai.agent import ai
        ai.available = False
    except Exception:
        pass


class LocalClient:
    def __init__(self):
        self.pid = None
        self.info = {}
        self.since = time.time()
        self.addr = "local"

    async def send_json(self, payload):
        _emit(payload)

    async def send(self, payload):
        await self.send_json(payload)


def _error(message: str) -> None:
    _emit({"type": "error", "message": message})


async def _attach(pid: str) -> None:
    old = _CLIENT.pid
    if old and old != pid:
        await _TABLE.detach(old, _CLIENT)
    _CLIENT.pid = pid
    await _TABLE.attach(pid, _CLIENT)


async def _dispatch(data: dict) -> None:
    from app.ai.agent import ai  # noqa: F401
    from app.clientinfo import clean_client_info
    from app.game.engine import GameError
    from app.profiles import ProfileError

    t = data.get("type")
    try:
        if t == "client_info":
            _CLIENT.info = clean_client_info(data.get("info"))
        elif t == "login":
            pid = _PROFILES.login(data.get("id"))
            await _attach(pid["id"])
        elif t == "update_profile":
            if not _CLIENT.pid:
                raise ProfileError("先登录")
            await _TABLE.update_profile(_CLIENT.pid, data)
        elif t == "state":
            if _CLIENT.pid:
                await _TABLE.send_to(_CLIENT.pid)
        elif t == "ping":
            await _CLIENT.send({"type": "pong", "t": data.get("t")})
        elif t == "leave":
            if _CLIENT.pid:
                await _TABLE.leave(_CLIENT.pid)
                _CLIENT.pid = None
            await _CLIENT.send({"type": "left"})
        else:
            if not _CLIENT.pid:
                raise GameError("先报上你的 ID")
            if t == "sit":
                await _TABLE.sit(_CLIENT.pid)
            elif t == "start":
                await _TABLE.set_ready(_CLIENT.pid, True)
            elif t == "ready":
                await _TABLE.set_ready(_CLIENT.pid, bool(data.get("value", True)))
            elif t == "kick":
                target = data.get("pid") or data.get("target")
                if not target:
                    raise GameError("没指定要请离谁")
                await _TABLE.kick(_CLIENT.pid, str(target))
            elif t == "update_settings":
                settings = data.get("settings")
                if not isinstance(settings, dict):
                    raise GameError("设置格式不对")
                await _TABLE.update_settings(_CLIENT.pid, settings)
            elif t == "set_difficulty":
                await _TABLE.set_difficulty(_CLIENT.pid, str(data.get("level", "")))
            elif t == "grab":
                await _TABLE.grab(_CLIENT.pid, bool(data.get("want", True)))
            elif t == "call":
                await _TABLE.call(_CLIENT.pid, bool(data.get("want", True)))
            elif t == "bid":
                await _TABLE.call(_CLIENT.pid, int(data.get("score", 0)) > 0)
            elif t == "play":
                cards = data.get("cards") or []
                if not isinstance(cards, list):
                    raise GameError("出牌数据格式错误")
                await _TABLE.play(_CLIENT.pid, [int(x) for x in cards])
            elif t == "pass":
                await _TABLE.pass_turn(_CLIENT.pid)
            elif t == "hint":
                hints = await _TABLE.hint(_CLIENT.pid)
                await _CLIENT.send({"type": "hints", "hints": hints})
            else:
                _error(f"未知操作: {t}")
    except (ProfileError, GameError) as exc:
        _error(str(exc))
    except Exception:
        import traceback
        traceback.print_exc()
        _error("本机处理失败，请重试")


def connect() -> None:
    global _CLIENT
    if not _READY:
        return
    _CLIENT = LocalClient()
    _emit({"type": "hello", "url": _LAN_URL, "title": "摩尔庄园 · 斗地主"})
    asyncio.ensure_future(_resume())


async def _resume() -> None:
    try:
        await _TABLE.resume()
    except Exception:
        import traceback
        traceback.print_exc()


def handle(text: str) -> None:
    if not _READY:
        return
    try:
        data = json.loads(text)
    except Exception:
        return
    if isinstance(data, dict):
        asyncio.ensure_future(_dispatch(data))


def disconnect() -> None:
    if _READY and _CLIENT and _CLIENT.pid:
        asyncio.ensure_future(_TABLE.detach(_CLIENT.pid, _CLIENT))


def _meta_payload() -> dict:
    m = _META
    curve = [{"level": level, "need": m.xp_to_next(level)} for level in range(1, m.MAX_LEVEL)]
    return {
        "avatars": m.AVATARS,
        "ram_colors": m.RAM_COLORS,
        "ram_stages": m.RAM_STAGES,
        "difficulties": [
            {"key": key, "label": m.DIFFICULTY_LABELS[key], "note": m.DIFFICULTY_NOTES[key]}
            for key in m.DIFFICULTIES
        ],
        "leveling": {
            "max_level": m.MAX_LEVEL,
            "win_xp_per_multiplier": m.WIN_XP_PER_MULTIPLIER,
            "curve": curve,
            "titles": {str(level): title for level, title in sorted(m.LEVEL_TITLES)},
        },
        "lan_url": _LAN_URL,
    }


def _info_payload() -> dict:
    return {
        "lan_ip": "127.0.0.1",
        "port": 0,
        "url": _LAN_URL,
        "hostname": "本机",
        "ai": {
            "engine": "本机牌局引擎",
            "device": "wasm",
            "available": False,
            "error": "",
        },
    }


def _qr_svg(text: str) -> str:
    label = (text or "本机牌桌")[:40]
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 120 120">'
        '<rect width="120" height="120" rx="16" fill="#fffaf0"/>'
        '<text x="60" y="62" text-anchor="middle" font-size="12" fill="#4f7d57">本机牌桌</text>'
        f'<text x="60" y="82" text-anchor="middle" font-size="9" fill="#7d6a55">{label}</text>'
        "</svg>"
    )


def api(path: str) -> str:
    if not _READY:
        return json.dumps({"status": 503, "body": {"error": "引擎还没就绪"}, "content_type": "application/json"})
    parsed = urlparse(path)
    route = parsed.path
    query = parse_qs(parsed.query)
    try:
        if route == "/api/info":
            return json.dumps({"status": 200, "body": _info_payload(), "content_type": "application/json"})
        if route == "/api/meta":
            return json.dumps({"status": 200, "body": _meta_payload(), "content_type": "application/json"})
        if route == "/api/leaderboard":
            return json.dumps({"status": 200, "body": {"rows": _PROFILES.leaderboard(10)}, "content_type": "application/json"})
        if route == "/api/history":
            limit = int((query.get("limit") or ["20"])[0])
            return json.dumps({"status": 200, "body": {"rows": _HISTORY.recent(limit)}, "content_type": "application/json"})
        if route == "/api/clients":
            rows = [{
                "pid": c.pid,
                "addr": "local",
                "online_s": round(time.time() - c.since, 1),
                "info": c.info,
            } for c in _TABLE.clients.values()]
            return json.dumps({"status": 200, "body": {"count": len(rows), "clients": rows}, "content_type": "application/json"})
        if route == "/api/qr.svg":
            text = (query.get("text") or [_LAN_URL])[0]
            return json.dumps({"status": 200, "body": _qr_svg(text), "content_type": "image/svg+xml"})
        if route.startswith("/api/profile/"):
            pid = unquote(route[len("/api/profile/"):])
            profile = _PROFILES.snapshot(pid)
            if not profile:
                return json.dumps({"status": 404, "body": {"error": "玩家不存在"}, "content_type": "application/json"})
            return json.dumps({"status": 200, "body": profile, "content_type": "application/json"})
        return json.dumps({"status": 404, "body": {"error": "not found"}, "content_type": "application/json"})
    except Exception as exc:
        import traceback
        traceback.print_exc()
        return json.dumps({"status": 500, "body": {"error": str(exc)}, "content_type": "application/json"})
