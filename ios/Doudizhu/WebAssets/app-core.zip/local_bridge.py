"""端侧 Pyodide 桥：复用正式服的 table / engine / profiles，不跑 HTTP 服务。

JS 侧提供 __manorSend(text) 把服务端消息推回页面；
页面通过 local_bridge.handle(text) 发消息，local_bridge.api(path) 取 REST 数据。
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from datetime import datetime, timezone
from urllib.parse import parse_qs, unquote, urlparse

_READY = False
_CLIENT = None
_REMOTE: dict[str, "LocalClient"] = {}
_TABLE = None
_PROFILES = None
_META = None
_HISTORY = None
_LAN_URL = "http://127.0.0.1/"
_JUST_CREATED: set[str] = set()
_AI = None


def _emit(payload) -> None:
    try:
        from js import __manorSend
        __manorSend(json.dumps(payload, ensure_ascii=False))
    except Exception:
        pass


def _emit_host(peer: str, payload) -> None:
    try:
        from js import manorHostSend
        manorHostSend(peer, json.dumps(payload, ensure_ascii=False))
    except Exception:
        pass


def init(data_dir: str) -> None:
    global _READY, _TABLE, _PROFILES, _META, _HISTORY
    if _READY:
        return
    os.environ["DOUDIZHU_DATA_DIR"] = data_dir
    os.makedirs(data_dir, exist_ok=True)
    if "/home/pyodide" not in sys.path:
        sys.path.insert(0, "/home/pyodide")

    # Pyodide 没有线程；AI 很小，直接同步算，await 语义保持不变。
    async def _to_thread(func, *args, **kwargs):
        return func(*args, **kwargs)

    asyncio.to_thread = _to_thread

    from app import meta as meta_mod
    from app import history as history_mod

    # 先用 NumPy 版 DouZero 顶替正式服的 torch agent，再导入 table/bidding。
    agent_mod = None
    try:
        import app.ai.agent as agent_mod
        from local_ai import NumpyDouZeroAI
        local_ai = NumpyDouZeroAI("/models")
        if local_ai.available:
            agent_mod.ai = local_ai
            print("local DouZero ready", flush=True)
        else:
            print("local DouZero unavailable: " + local_ai.error, flush=True)
    except Exception:
        import traceback
        traceback.print_exc()

    from app.table import table as table_obj
    from app.profiles import profiles as profiles_obj

    global _AI
    _AI = getattr(agent_mod, "ai", None) if agent_mod is not None else None
    _TABLE = table_obj
    _PROFILES = profiles_obj
    _META = meta_mod
    _HISTORY = history_mod
    _READY = True
    try:
        from app.ai.agent import ai
        ai.available = False
    except Exception:
        pass


class LocalClient:
    def __init__(self, peer_id: str | None = None):
        self.peer_id = peer_id
        self.pid = None
        self.info = {}
        self.since = time.time()
        self.addr = "local" if peer_id is None else f"mcs:{peer_id}"

    async def send_json(self, payload):
        if self.peer_id:
            _emit_host(self.peer_id, payload)
        else:
            _emit(payload)

    async def send(self, payload):
        await self.send_json(payload)


def _error(message: str, client: LocalClient | None = None) -> None:
    if client is not None:
        asyncio.ensure_future(client.send({"type": "error", "message": message}))
    else:
        _emit({"type": "error", "message": message})


async def _attach(pid: str, client: LocalClient | None = None) -> None:
    target = client or _CLIENT
    old = target.pid
    if old and old != pid:
        await _TABLE.detach(old, target)
    target.pid = pid
    await _TABLE.attach(pid, target)


async def _dispatch(data: dict, client: LocalClient | None = None) -> None:
    from app.ai.agent import ai  # noqa: F401
    from app.clientinfo import clean_client_info
    from app.game.engine import GameError
    from app.profiles import ProfileError

    target = client or _CLIENT
    t = data.get("type")
    try:
        if t == "client_info":
            target.info = clean_client_info(data.get("info"))
        elif t == "login":
            pid = _PROFILES.login(data.get("id"))
            await _attach(pid["id"], target)
        elif t == "update_profile":
            if not target.pid:
                raise ProfileError("先登录")
            await _TABLE.update_profile(target.pid, data)
        elif t == "state":
            if target.pid:
                await _TABLE.send_to(target.pid)
        elif t == "ping":
            await target.send({"type": "pong", "t": data.get("t")})
        elif t == "leave":
            if target.pid:
                await _TABLE.leave(target.pid)
                target.pid = None
            await target.send({"type": "left"})
        else:
            if not target.pid:
                raise GameError("先报上你的 ID")
            if t == "sit":
                await _TABLE.sit(target.pid)
            elif t == "start":
                await _TABLE.set_ready(target.pid, True)
            elif t == "ready":
                await _TABLE.set_ready(target.pid, bool(data.get("value", True)))
            elif t == "kick":
                kick_target = data.get("pid") or data.get("target")
                if not kick_target:
                    raise GameError("没指定要请离谁")
                await _TABLE.kick(target.pid, str(kick_target))
            elif t == "update_settings":
                settings = data.get("settings")
                if not isinstance(settings, dict):
                    raise GameError("设置格式不对")
                await _TABLE.update_settings(target.pid, settings)
            elif t == "set_difficulty":
                await _TABLE.set_difficulty(target.pid, str(data.get("level", "")))
            elif t == "grab":
                await _TABLE.grab(target.pid, bool(data.get("want", True)))
            elif t == "call":
                await _TABLE.call(target.pid, bool(data.get("want", True)))
            elif t == "bid":
                await _TABLE.call(target.pid, int(data.get("score", 0)) > 0)
            elif t == "play":
                cards = data.get("cards") or []
                if not isinstance(cards, list):
                    raise GameError("出牌数据格式错误")
                await _TABLE.play(target.pid, [int(x) for x in cards])
            elif t == "pass":
                await _TABLE.pass_turn(target.pid)
            elif t == "hint":
                hints = await _TABLE.hint(target.pid)
                await target.send({"type": "hints", "hints": hints})
            else:
                _error(f"未知操作: {t}", target)
    except (ProfileError, GameError) as exc:
        _error(str(exc), target)
    except Exception:
        import traceback
        traceback.print_exc()
        _error("本机处理失败，请重试", target)


def _import_profile(profile) -> None:
    if not isinstance(profile, dict):
        return
    pid = profile.get("id")
    if not pid:
        return
    with _PROFILES._lock:
        current = _PROFILES._players.get(pid) or _PROFILES._new_profile(pid)
        for key in (
            "xp", "wins", "losses", "games", "best_multiplier",
            "avatar", "ram_color", "ram_name", "settings", "last_seen", "updated_at", "created",
        ):
            if key in profile:
                current[key] = profile[key]
        _PROFILES._players[pid] = current
        _PROFILES._save()


def host_receive(peer: str, text: str) -> None:
    if not _READY:
        return
    try:
        data = json.loads(text)
    except Exception:
        return
    if not isinstance(data, dict):
        return
    profile = data.pop("profile", None) if data.get("type") == "login" else None
    if profile:
        _import_profile(profile)
    client = _REMOTE.get(peer)
    if client is None:
        client = LocalClient(peer_id=peer)
        _REMOTE[peer] = client
    asyncio.ensure_future(_dispatch(data, client))


def host_leave(peer: str) -> None:
    client = _REMOTE.pop(peer, None)
    if client is None:
        return
    if client.pid:
        asyncio.ensure_future(_TABLE.detach(client.pid, client))


def apply_profile(text: str) -> None:
    if not _READY:
        return
    try:
        profile = json.loads(text)
    except Exception:
        return
    _import_profile(profile)


def ensure_profile(raw_id: str) -> str:
    if not _READY:
        return "{}"
    try:
        existed = _PROFILES.exists(raw_id)
        profile = _PROFILES.login(raw_id)
        if not existed:
            # 新设备上的 0 进度占位档案；第一次同步时让服务器装扮覆盖本地默认。
            _JUST_CREATED.add(profile["id"])
        return json.dumps(profile, ensure_ascii=False)
    except Exception:
        return "{}"


def sync_export() -> str:
    """给原生同步层：导出本机原始档案和最近 200 局牌谱。"""
    if not _READY:
        return json.dumps({"players": [], "history": []}, ensure_ascii=False)
    try:
        return json.dumps(
            {"players": _PROFILES.export_all(), "history": _HISTORY.export_records(200)},
            ensure_ascii=False,
        )
    except Exception:
        return json.dumps({"players": [], "history": []}, ensure_ascii=False)


def sync_import(text: str) -> str:
    """合并服务器/同伴回来的档案；计数取大，装扮取较新的。"""
    if not _READY:
        return json.dumps({"players": []}, ensure_ascii=False)
    try:
        data = json.loads(text)
    except Exception:
        return json.dumps({"players": []}, ensure_ascii=False)
    if not isinstance(data, dict):
        return json.dumps({"players": [], "history_added": 0}, ensure_ascii=False)
    players = data.get("players") if isinstance(data.get("players"), list) else []
    merged = []
    if players:
        try:
            preferred = set(_JUST_CREATED)
            merged = _PROFILES.merge_many(players, prefer_incoming_ids=preferred)
            _JUST_CREATED.difference_update(preferred)
        except Exception:
            import traceback
            traceback.print_exc()
    history_added = 0
    history = data.get("history")
    if isinstance(history, list) and history:
        try:
            history_added = _HISTORY.merge_records(history)
        except Exception:
            import traceback
            traceback.print_exc()
    # 已登录的牌桌客户端立刻补一份 state，经验/等级/拉姆马上刷新。
    ids = {item.get("id") for item in merged if isinstance(item, dict)}
    if ids and _TABLE is not None:
        for pid in list(_TABLE.clients.keys()):
            if pid in ids:
                asyncio.ensure_future(_TABLE.send_to(pid))
    return json.dumps(
        {"players": merged, "history_added": history_added}, ensure_ascii=False
    )


def connect() -> None:
    global _CLIENT
    if not _READY:
        return
    _CLIENT = LocalClient()
    _emit({"type": "hello", "url": _LAN_URL, "title": "摩尔庄园 · 斗地主"})
    asyncio.ensure_future(_resume())


async def _resume() -> None:
    try:
        await _TABLE.resume()
    except Exception:
        import traceback
        traceback.print_exc()


def handle(text: str) -> None:
    if not _READY:
        return
    try:
        data = json.loads(text)
    except Exception:
        return
    if isinstance(data, dict):
        asyncio.ensure_future(_dispatch(data))


def disconnect() -> None:
    if _READY and _CLIENT and _CLIENT.pid:
        asyncio.ensure_future(_TABLE.detach(_CLIENT.pid, _CLIENT))


def _meta_payload() -> dict:
    m = _META
    curve = [{"level": level, "need": m.xp_to_next(level)} for level in range(1, m.MAX_LEVEL)]
    return {
        "avatars": m.AVATARS,
        "ram_colors": m.RAM_COLORS,
        "ram_stages": m.RAM_STAGES,
        "difficulties": [
            {"key": key, "label": m.DIFFICULTY_LABELS[key], "note": m.DIFFICULTY_NOTES[key]}
            for key in m.DIFFICULTIES
        ],
        "leveling": {
            "max_level": m.MAX_LEVEL,
            "win_xp_per_multiplier": m.WIN_XP_PER_MULTIPLIER,
            "curve": curve,
            "titles": {str(level): title for level, title in sorted(m.LEVEL_TITLES)},
        },
        "lan_url": _LAN_URL,
    }


def ai_status() -> str:
    ai = _AI
    if ai is None:
        return json.dumps(
            {"engine": "", "available": False, "error": "AI 未初始化", "device": "wasm"},
            ensure_ascii=False,
        )
    return json.dumps(
        {
            "engine": type(ai).__name__,
            "available": bool(getattr(ai, "available", False)),
            "error": str(getattr(ai, "error", "")),
            "device": "wasm",
        },
        ensure_ascii=False,
    )


def _info_payload() -> dict:
    try:
        ai = json.loads(ai_status())
    except Exception:
        ai = {"engine": "本机牌局引擎", "available": False, "error": "", "device": "wasm"}
    return {
        "lan_ip": "127.0.0.1",
        "port": 0,
        "url": _LAN_URL,
        "hostname": "本机",
        "ai": {
            "engine": ai.get("engine") or "本机牌局引擎",
            "device": ai.get("device") or "wasm",
            "available": bool(ai.get("available")),
            "error": ai.get("error") or "",
        },
    }


def _qr_svg(text: str) -> str:
    label = (text or "本机牌桌")[:40]
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120" viewBox="0 0 120 120">'
        '<rect width="120" height="120" rx="16" fill="#fffaf0"/>'
        '<text x="60" y="62" text-anchor="middle" font-size="12" fill="#4f7d57">本机牌桌</text>'
        f'<text x="60" y="82" text-anchor="middle" font-size="9" fill="#7d6a55">{label}</text>'
        "</svg>"
    )


def api(path: str) -> str:
    if not _READY:
        return json.dumps({"status": 503, "body": {"error": "引擎还没就绪"}, "content_type": "application/json"})
    parsed = urlparse(path)
    route = parsed.path
    query = parse_qs(parsed.query)
    try:
        if route == "/api/info":
            return json.dumps({"status": 200, "body": _info_payload(), "content_type": "application/json"})
        if route == "/api/meta":
            return json.dumps({"status": 200, "body": _meta_payload(), "content_type": "application/json"})
        if route == "/api/leaderboard":
            return json.dumps({"status": 200, "body": {"rows": _PROFILES.leaderboard(10)}, "content_type": "application/json"})
        if route == "/api/history":
            limit = int((query.get("limit") or ["20"])[0])
            return json.dumps({"status": 200, "body": {"rows": _HISTORY.recent(limit)}, "content_type": "application/json"})
        if route == "/api/clients":
            rows = [{
                "pid": c.pid,
                "addr": "local",
                "online_s": round(time.time() - c.since, 1),
                "info": c.info,
            } for c in _TABLE.clients.values()]
            return json.dumps({"status": 200, "body": {"count": len(rows), "clients": rows}, "content_type": "application/json"})
        if route == "/api/qr.svg":
            text = (query.get("text") or [_LAN_URL])[0]
            return json.dumps({"status": 200, "body": _qr_svg(text), "content_type": "image/svg+xml"})
        if route.startswith("/api/profile/"):
            pid = unquote(route[len("/api/profile/"):])
            profile = _PROFILES.snapshot(pid)
            if not profile:
                return json.dumps({"status": 404, "body": {"error": "玩家不存在"}, "content_type": "application/json"})
            return json.dumps({"status": 200, "body": profile, "content_type": "application/json"})
        return json.dumps({"status": 404, "body": {"error": "not found"}, "content_type": "application/json"})
    except Exception as exc:
        import traceback
        traceback.print_exc()
        return json.dumps({"status": 500, "body": {"error": str(exc)}, "content_type": "application/json"})
