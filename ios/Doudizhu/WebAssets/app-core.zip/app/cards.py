"""斗地主扑克牌基础表示.

54 张牌用 0..53 表示:
  0..51  = 点数 3..2 各四种花色 (rank * 4 + suit)
  52     = 小王
  53     = 大王

点数 rank 取值 3..15 (15 = 2), 16 = 小王, 17 = 大王。
"""

from __future__ import annotations

import random
from collections import Counter

SUITS = ("\u2660", "\u2665", "\u2663", "\u2666")  # 黑桃 红桃 梅花 方块
RANK_LABELS = {
    3: "3", 4: "4", 5: "5", 6: "6", 7: "7", 8: "8", 9: "9", 10: "10",
    11: "J", 12: "Q", 13: "K", 14: "A", 15: "2", 16: "小王", 17: "大王",
}

FULL_DECK = list(range(54))


def rank(card: int) -> int:
    if card == 52:
        return 16
    if card == 53:
        return 17
    return card // 4 + 3


def suit(card: int) -> int:
    """0..3 花色; 王返回 4。"""
    if card >= 52:
        return 4
    return card % 4


def is_joker(card: int) -> bool:
    return card >= 52


def is_red(card: int) -> bool:
    return suit(card) in (1, 3)


def card_label(card: int) -> str:
    return RANK_LABELS[rank(card)]


def sort_key(card: int):
    return (rank(card), suit(card))


def sort_cards(cards) -> list[int]:
    return sorted(cards, key=sort_key)


def rank_counts(cards) -> dict[int, int]:
    return dict(Counter(rank(c) for c in cards))


# DouZero 使用的牌点编码: 3..14, 2=17, 小王=20, 大王=30
DZ_RANK = {r: r for r in range(3, 15)}
DZ_RANK[15] = 17
DZ_RANK[16] = 20
DZ_RANK[17] = 30


def dz_rank(card: int) -> int:
    return DZ_RANK[rank(card)]


def to_dz(cards) -> list[int]:
    return [dz_rank(c) for c in cards]


def new_deck() -> list[int]:
    deck = FULL_DECK.copy()
    random.shuffle(deck)
    return deck


def deal(deck: list[int] | None = None) -> tuple[list[list[int]], list[int]]:
    deck = (deck or new_deck()).copy()
    hands = [sort_cards(deck[i * 17:(i + 1) * 17]) for i in range(3)]
    bottom = sort_cards(deck[51:54])
    return hands, bottom


def card_json(card: int) -> dict:
    return {
        "id": card,
        "r": rank(card),
        "s": suit(card),
        "label": card_label(card),
        "red": is_red(card),
    }
