"""角色、拉姆、等级等静态设定。

角色头像来自网络公开图片，仅作家庭局域网娱乐使用。
"""

from __future__ import annotations

DIFFICULTIES = ("easy", "normal", "hard", "master")
DIFFICULTY_LABELS = {
    "easy": "简单",
    "normal": "普通",
    "hard": "困难",
    "master": "大师",
}
DIFFICULTY_NOTES = {
    "easy": "偶尔会走神，适合刚学规则",
    "normal": "ADP 价值网络，爱进攻",
    "hard": "DouZero 原版 WP 权重",
    "master": "WP + ADP 双模型合议",
}

ORIGIN_LABELS = {"mole": "摩尔庄园", "genshin": "原神"}

# 摩尔庄园：么么公主与百度百科星图上的全部 9 位亲属/好友
AVATARS = [
    {"id": "mole_0", "origin": "mole", "name": "么么公主", "note": "摩尔庄园的小公主"},
    {"id": "mole_1", "origin": "mole", "name": "摩尔王八世", "note": "么么的父亲"},
    {"id": "mole_2", "origin": "mole", "name": "哈娜", "note": "温柔的王后"},
    {"id": "mole_3", "origin": "mole", "name": "塞拉王子", "note": "么么的孪生哥哥"},
    {"id": "mole_4", "origin": "mole", "name": "捷克王子", "note": "黑猫王子"},
    {"id": "mole_5", "origin": "mole", "name": "摩尔王七世", "note": "么么的祖父"},
    {"id": "mole_6", "origin": "mole", "name": "摩乐乐", "note": "乐乐侠"},
    {"id": "mole_7", "origin": "mole", "name": "丫丽", "note": "功夫少女"},
    {"id": "mole_8", "origin": "mole", "name": "瑞琪", "note": "皇家骑士团团长"},
    {"id": "mole_9", "origin": "mole", "name": "其其", "note": "RK 联盟的小队长"},
    {"id": "genshin_0", "origin": "genshin", "name": "可莉", "note": "逃跑的太阳"},
    {"id": "genshin_1", "origin": "genshin", "name": "胡桃", "note": "往生堂七十七代堂主"},
    {"id": "genshin_2", "origin": "genshin", "name": "钟离", "note": "往生堂客卿"},
    {"id": "genshin_3", "origin": "genshin", "name": "雷电将军", "note": "一心净土"},
    {"id": "genshin_4", "origin": "genshin", "name": "纳西妲", "note": "小吉祥草王"},
    {"id": "genshin_5", "origin": "genshin", "name": "芙宁娜", "note": "水色的舞台"},
    {"id": "genshin_6", "origin": "genshin", "name": "派蒙", "note": "最好的向导"},
    {"id": "genshin_7", "origin": "genshin", "name": "温迪", "note": "风色诗人"},
    {"id": "genshin_8", "origin": "genshin", "name": "甘雨", "note": "月海亭秘书"},
    {"id": "genshin_9", "origin": "genshin", "name": "宵宫", "note": "琉焰华舞"},
]
AVATAR_MAP = {a["id"]: a for a in AVATARS}
DEFAULT_AVATAR = "mole_0"

for _a in AVATARS:
    _a["url"] = f"/static/assets/avatars/{_a['id']}.jpg"

# 原版拉姆的基础色系，另补了几种常见颜色
RAM_COLORS = [
    {"id": "pink", "name": "樱花粉", "hex": "#f29ab5"},
    {"id": "red", "name": "草莓红", "hex": "#e86a72"},
    {"id": "blue", "name": "湖水蓝", "hex": "#6fb6e3"},
    {"id": "yellow", "name": "柠檬黄", "hex": "#f2ca57"},
    {"id": "purple", "name": "葡萄紫", "hex": "#a98ad6"},
    {"id": "green", "name": "嫩芽绿", "hex": "#83bf7a"},
    {"id": "orange", "name": "蜜橘橙", "hex": "#efa05a"},
    {"id": "black", "name": "夜空黑", "hex": "#565264"},
    {"id": "gray", "name": "云朵灰", "hex": "#b4bec4"},
    {"id": "cream", "name": "奶白", "hex": "#f7edd6"},
    {"id": "brown", "name": "可可棕", "hex": "#a97a58"},
    {"id": "ink", "name": "纯黑", "hex": "#000000"},
    {"id": "white", "name": "纯白", "hex": "#ffffff"},
]
RAM_COLOR_MAP = {c["id"]: c for c in RAM_COLORS}
DEFAULT_RAM_COLOR = "pink"
DEFAULT_RAM_NAME = "小拉姆"

# 拉姆随摩尔等级成长：种子 → 初级 → 中级 → 高级 → 超级 → 神力
RAM_STAGES = [
    {"key": "seed", "name": "拉姆种子", "min_level": 1},
    {"key": "baby", "name": "初级拉姆", "min_level": 2},
    {"key": "middle", "name": "中级拉姆", "min_level": 4},
    {"key": "high", "name": "高级拉姆", "min_level": 7},
    {"key": "super", "name": "超级拉姆", "min_level": 11},
    {"key": "god", "name": "神力拉姆", "min_level": 17},
]

LEVEL_TITLES = [
    (35, "传奇摩尔"),
    (25, "庄园守护者"),
    (17, "皇家骑士"),
    (11, "庄园名人"),
    (7, "资深摩尔"),
    (4, "庄园居民"),
    (2, "见习摩尔"),
    (1, "新芽摩尔"),
]

MAX_LEVEL = 60
WIN_XP_PER_MULTIPLIER = 20


def level_title(level: int) -> str:
    for need, title in LEVEL_TITLES:
        if level >= need:
            return title
    return LEVEL_TITLES[-1][1]


def xp_to_next(level: int) -> int:
    """从 level 升到 level+1 所需经验。满级返回 0。"""
    if level >= MAX_LEVEL:
        return 0
    return 60 + 30 * (level - 1)


def level_from_xp(total_xp: int) -> tuple[int, int, int]:
    """返回 (等级, 当前等级内经验, 升下一级所需经验)。"""
    total_xp = max(0, int(total_xp))
    level = 1
    left = total_xp
    while level < MAX_LEVEL:
        need = xp_to_next(level)
        if left < need:
            break
        left -= need
        level += 1
    return level, left, xp_to_next(level)


def ram_for_level(level: int, color_id: str = DEFAULT_RAM_COLOR, name: str = DEFAULT_RAM_NAME) -> dict:
    color = RAM_COLOR_MAP.get(color_id) or RAM_COLOR_MAP[DEFAULT_RAM_COLOR]
    index = 0
    for i, stage in enumerate(RAM_STAGES):
        if level >= stage["min_level"]:
            index = i
    stage = RAM_STAGES[index]
    nxt = RAM_STAGES[index + 1] if index + 1 < len(RAM_STAGES) else None
    return {
        "name": name or DEFAULT_RAM_NAME,
        "color_id": color["id"],
        "color_name": color["name"],
        "color": color["hex"],
        "level": level,
        "stage": stage["key"],
        "stage_name": stage["name"],
        "next_stage": nxt["name"] if nxt else None,
        "next_stage_at": nxt["min_level"] if nxt else None,
    }


def avatar_url(avatar_id: str) -> str:
    meta = AVATAR_MAP.get(avatar_id) or AVATAR_MAP[DEFAULT_AVATAR]
    return meta["url"]


BOT_PERSONAS = [
    {"name": "乐乐", "avatar": "mole_6"},
    {"name": "丫丽", "avatar": "mole_7"},
    {"name": "瑞琪", "avatar": "mole_8"},
    {"name": "其其", "avatar": "mole_9"},
    {"name": "派蒙", "avatar": "genshin_6"},
    {"name": "小吉祥", "avatar": "genshin_4"},
    {"name": "可莉", "avatar": "genshin_0"},
    {"name": "宵宫", "avatar": "genshin_9"},
]
