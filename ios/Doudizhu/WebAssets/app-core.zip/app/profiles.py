"""玩家档案：只认 ID，不需要密码；经验、等级、头像、拉姆持久化。"""

from __future__ import annotations

import copy
import json
import logging
import os
import re
import shutil
import threading
from datetime import datetime, timezone
from pathlib import Path

from .meta import (
    AVATAR_MAP,
    DEFAULT_AVATAR,
    DEFAULT_RAM_COLOR,
    DEFAULT_RAM_NAME,
    MAX_LEVEL,
    RAM_COLOR_MAP,
    RAM_STAGES,
    WIN_XP_PER_MULTIPLIER,
    level_from_xp,
    level_title,
    ram_for_level,
)
from .paths import DATA_DIR

log = logging.getLogger(__name__)

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_PATH = DATA_DIR / "players.json"


class ProfileError(ValueError):
    pass


SETTINGS_DEFAULT = {"hand_order": "asc"}
HAND_ORDERS = ("asc", "desc")


def clean_settings(raw) -> dict:
    """只保留认识的设置项，旧档案缺字段时给默认值。"""
    settings = dict(SETTINGS_DEFAULT)
    if isinstance(raw, dict):
        order = raw.get("hand_order")
        if order in HAND_ORDERS:
            settings["hand_order"] = order
    return settings


def clean_id(raw) -> str:
    text = str(raw or "")
    # 控制字符视作空白，压缩后限制 12 个字符
    text = "".join(ch if ch.isprintable() else " " for ch in text)
    text = re.sub(r"\s+", " ", text).strip()
    text = text[:12]
    if not text:
        raise ProfileError("先给自己取一个 ID 吧")
    return text


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class ProfileStore:
    def __init__(self, path: str | Path | None = None, *, auto_save: bool = True):
        self.path = Path(path) if path else DEFAULT_PATH
        self.auto_save = auto_save
        self._lock = threading.RLock()
        self._players: dict[str, dict] = {}
        self._load()

    # ------------------------------------------------------------------ io

    def _load(self):
        if not self.path.exists():
            self._players = {}
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            players = data.get("players") if isinstance(data, dict) else None
            if not isinstance(players, dict):
                raise ValueError("players 字段缺失")
            self._players = {
                str(k): v for k, v in players.items() if isinstance(v, dict)
            }
        except Exception:
            log.exception("玩家档案读取失败，已备份并重新开始")
            try:
                broken = self.path.with_suffix(self.path.suffix + ".broken")
                shutil.copy2(self.path, broken)
            except Exception:
                pass
            self._players = {}

    def _save(self):
        if not self.auto_save:
            return
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"version": 1, "saved_at": _now(), "players": self._players}
        tmp = self.path.with_name(self.path.name + ".tmp")
        tmp.write_text(
            json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8"
        )
        os.replace(tmp, self.path)

    # -------------------------------------------------------------- profile

    def _new_profile(self, pid: str) -> dict:
        return {
            "id": pid,
            "created": _now(),
            "last_seen": _now(),
            "xp": 0,
            "wins": 0,
            "losses": 0,
            "games": 0,
            "best_multiplier": 0,
            "avatar": DEFAULT_AVATAR,
            "ram_color": DEFAULT_RAM_COLOR,
            "ram_name": DEFAULT_RAM_NAME,
            "settings": dict(SETTINGS_DEFAULT),
        }

    def _get(self, pid: str) -> dict | None:
        return self._players.get(pid)

    def exists(self, pid: str) -> bool:
        try:
            return clean_id(pid) in self._players
        except ProfileError:
            return False

    def login(self, raw_id) -> dict:
        pid = clean_id(raw_id)
        with self._lock:
            profile = self._get(pid)
            if profile is None:
                profile = self._new_profile(pid)
                self._players[pid] = profile
            else:
                profile["last_seen"] = _now()
                # 兼容早期字段缺失
                profile.setdefault("xp", 0)
                profile.setdefault("wins", 0)
                profile.setdefault("losses", 0)
                profile.setdefault("games", 0)
                profile.setdefault("best_multiplier", 0)
                profile.setdefault("avatar", DEFAULT_AVATAR)
                profile.setdefault("ram_color", DEFAULT_RAM_COLOR)
                profile.setdefault("ram_name", DEFAULT_RAM_NAME)
            profile["settings"] = clean_settings(profile.get("settings"))
            self._save()
            return self.public(profile)

    def update(self, raw_id, *, avatar=None, ram_color=None, ram_name=None) -> dict:
        pid = clean_id(raw_id)
        with self._lock:
            profile = self._get(pid)
            if profile is None:
                raise ProfileError("玩家不存在")
            if avatar is not None:
                if avatar not in AVATAR_MAP:
                    raise ProfileError("没有这个角色形象")
                profile["avatar"] = avatar
            if ram_color is not None:
                if ram_color not in RAM_COLOR_MAP:
                    raise ProfileError("没有这个拉姆颜色")
                profile["ram_color"] = ram_color
            if ram_name is not None:
                name = str(ram_name).strip()[:8]
                if not name:
                    raise ProfileError("拉姆的名字不能为空")
                profile["ram_name"] = name
            profile["last_seen"] = _now()
            self._save()
            return self.public(profile)

    def update_settings(self, raw_id, data: dict) -> dict:
        """按 ID 记住牌桌设置，换设备登录也还在。"""
        pid = clean_id(raw_id)
        if not isinstance(data, dict):
            raise ProfileError("设置格式不对")
        with self._lock:
            profile = self._get(pid)
            if profile is None:
                raise ProfileError("玩家不存在")
            settings = clean_settings(profile.get("settings"))
            if "hand_order" in data:
                order = data.get("hand_order")
                if order not in HAND_ORDERS:
                    raise ProfileError("手牌顺序只能是 asc 或 desc")
                settings["hand_order"] = order
            profile["settings"] = settings
            profile["last_seen"] = _now()
            self._save()
            return self.public(profile)

    def record_result(self, raw_id, *, won: bool, multiplier: int) -> dict:
        """每局结算调用一次。赢了加经验，输了不扣；都记场次。"""
        pid = clean_id(raw_id)
        multiplier = max(1, int(multiplier or 1))
        with self._lock:
            profile = self._get(pid)
            if profile is None:
                raise ProfileError("玩家不存在")
            before_level, _, _ = level_from_xp(profile.get("xp", 0))
            before_ram = ram_for_level(
                before_level,
                profile.get("ram_color", DEFAULT_RAM_COLOR),
                profile.get("ram_name", DEFAULT_RAM_NAME),
            )

            gain = WIN_XP_PER_MULTIPLIER * multiplier if won else 0
            profile["games"] = int(profile.get("games", 0)) + 1
            if won:
                profile["wins"] = int(profile.get("wins", 0)) + 1
                profile["xp"] = int(profile.get("xp", 0)) + gain
                profile["best_multiplier"] = max(
                    int(profile.get("best_multiplier", 0)), multiplier
                )
            else:
                profile["losses"] = int(profile.get("losses", 0)) + 1
            profile["last_seen"] = _now()
            self._save()

            after_level, _, _ = level_from_xp(profile["xp"])
            after_ram = ram_for_level(
                after_level,
                profile.get("ram_color", DEFAULT_RAM_COLOR),
                profile.get("ram_name", DEFAULT_RAM_NAME),
            )
            return {
                "won": won,
                "xp_gain": gain,
                "multiplier": multiplier,
                "level_before": before_level,
                "level_after": after_level,
                "level_up": after_level > before_level,
                "level_title_before": level_title(before_level),
                "level_title_after": level_title(after_level),
                "xp": profile["xp"],
                "ram_before": before_ram["stage_name"],
                "ram_after": after_ram["stage_name"],
                "ram_up": after_ram["stage"] != before_ram["stage"],
            }

    # ----------------------------------------------------------------- read

    def public(self, profile: dict) -> dict:
        level, level_xp, level_need = level_from_xp(profile.get("xp", 0))
        ram = ram_for_level(
            level,
            profile.get("ram_color", DEFAULT_RAM_COLOR),
            profile.get("ram_name", DEFAULT_RAM_NAME),
        )
        avatar = profile.get("avatar") if profile.get("avatar") in AVATAR_MAP else DEFAULT_AVATAR
        next_stage = None
        for stage in RAM_STAGES:
            if stage["min_level"] > level:
                next_stage = stage
                break
        return {
            "id": profile["id"],
            "level": level,
            "level_title": level_title(level),
            "max_level": MAX_LEVEL,
            "xp": int(profile.get("xp", 0)),
            "level_xp": level_xp,
            "level_need": level_need,
            "xp_pct": round(level_xp / level_need, 4) if level_need else 1.0,
            "wins": int(profile.get("wins", 0)),
            "losses": int(profile.get("losses", 0)),
            "games": int(profile.get("games", 0)),
            "best_multiplier": int(profile.get("best_multiplier", 0)),
            "avatar": avatar,
            "avatar_meta": AVATAR_MAP[avatar],
            "ram": ram,
            "ram_next": next_stage,
            "settings": clean_settings(profile.get("settings")),
        }

    def snapshot(self, raw_id) -> dict | None:
        try:
            pid = clean_id(raw_id)
        except ProfileError:
            return None
        with self._lock:
            profile = self._get(pid)
            return self.public(profile) if profile else None

    # --------------------------------------------------------------- sync

    def export_all(self) -> list[dict]:
        """端侧同步用的原始档案（含 last_seen，方便合并装扮和设置）。"""
        with self._lock:
            return copy.deepcopy(list(self._players.values()))

    def merge_many(self, players) -> list[dict]:
        """把另一台设备/服务端的档案并进来；计数取大，装扮取较新的。

        只认已有字段，ID 不合法或结构不对的条目直接跳过。家庭局域网，不做账号鉴权。
        """
        if not isinstance(players, list):
            raise ProfileError("档案格式不对")
        if len(players) > 100:
            raise ProfileError("一次同步的档案太多了")
        merged: list[dict] = []
        with self._lock:
            for raw in players:
                if not isinstance(raw, dict):
                    continue
                try:
                    pid = clean_id(raw.get("id"))
                except ProfileError:
                    continue
                current = self._players.get(pid)
                is_new = current is None
                if current is None:
                    current = self._new_profile(pid)
                self._merge_locked(current, raw, is_new=is_new)
                self._players[pid] = current
                merged.append(copy.deepcopy(current))
            if merged:
                self._save()
        return merged

    def _merge_locked(self, current: dict, raw: dict, *, is_new: bool) -> None:
        def counter(value, cap: int = 1_000_000_000) -> int:
            try:
                return max(0, min(int(value), cap))
            except (TypeError, ValueError):
                return 0

        for key in ("xp", "wins", "losses", "games", "best_multiplier"):
            current[key] = max(counter(current.get(key)), counter(raw.get(key)))

        created = str(raw.get("created") or "").strip()
        if created and (not current.get("created") or created < current["created"]):
            current["created"] = created
        last_seen = str(raw.get("last_seen") or "").strip()
        incoming_is_newer = bool(last_seen) and last_seen >= str(current.get("last_seen") or "")
        if incoming_is_newer:
            current["last_seen"] = last_seen

        # 装扮/设置跟随较新的那份；新档案直接接受对端内容。
        if is_new or incoming_is_newer:
            avatar = raw.get("avatar")
            if avatar in AVATAR_MAP:
                current["avatar"] = avatar
            color = raw.get("ram_color")
            if color in RAM_COLOR_MAP:
                current["ram_color"] = color
            name = str(raw.get("ram_name") or "").strip()[:8]
            if name:
                current["ram_name"] = name
            if isinstance(raw.get("settings"), dict):
                current["settings"] = clean_settings(raw["settings"])

        current.setdefault("avatar", DEFAULT_AVATAR)
        current.setdefault("ram_color", DEFAULT_RAM_COLOR)
        current.setdefault("ram_name", DEFAULT_RAM_NAME)
        current["settings"] = clean_settings(current.get("settings"))

    def leaderboard(self, limit: int = 10) -> list[dict]:
        with self._lock:
            rows = [self.public(p) for p in self._players.values()]
        rows.sort(key=lambda p: (p["level"], p["xp"], p["wins"]), reverse=True)
        return [
            {
                "rank": i + 1,
                "id": p["id"],
                "level": p["level"],
                "level_title": p["level_title"],
                "wins": p["wins"],
                "avatar": p["avatar"],
                "avatar_url": p["avatar_meta"]["url"],
                "ram": p["ram"],
            }
            for i, p in enumerate(rows[:limit])
        ]


profiles = ProfileStore()
