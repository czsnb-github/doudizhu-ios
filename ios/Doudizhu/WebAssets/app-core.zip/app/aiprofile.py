"""AI 共用档案：所有难度的机器人共用同一个等级和战绩。

存在 data/ai.json（dev 环境是 dev-data/ai.json）。
机器人赢一局，全体 AI 加 20 × 倍数经验；输了不加也不扣。
"""

from __future__ import annotations

import json
import logging
import threading
from datetime import datetime, timezone
from pathlib import Path

from .meta import WIN_XP_PER_MULTIPLIER, level_from_xp, level_title
from .paths import DATA_DIR

log = logging.getLogger(__name__)

PATH = DATA_DIR / "ai.json"
_lock = threading.Lock()
_cache: dict | None = None


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _load() -> dict:
    global _cache
    if _cache is not None:
        return _cache
    raw: dict = {}
    if PATH.exists():
        try:
            raw = json.loads(PATH.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                raw = {}
        except Exception:
            log.exception("ai.json 读取失败，重置 AI 档案")
            raw = {}
    _cache = {
        "xp": max(0, int(raw.get("xp") or 0)),
        "wins": max(0, int(raw.get("wins") or 0)),
        "games": max(0, int(raw.get("games") or 0)),
        "best_multiplier": max(0, int(raw.get("best_multiplier") or 0)),
    }
    return _cache


def _save() -> None:
    data = _load()
    payload = {
        "version": 1,
        "updated": _now(),
        "xp": data["xp"],
        "wins": data["wins"],
        "games": data["games"],
        "best_multiplier": data["best_multiplier"],
    }
    tmp = PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(PATH)


def reset() -> None:
    """测试/运维用：清空 AI 档案。"""
    global _cache
    with _lock:
        _cache = {"xp": 0, "wins": 0, "games": 0, "best_multiplier": 0}
        _save()


def snapshot() -> dict:
    with _lock:
        data = dict(_load())
    level, in_level, need = level_from_xp(data["xp"])
    games = data["games"]
    wins = data["wins"]
    return {
        "id": "AI",
        "is_ai": True,
        "xp": data["xp"],
        "level": level,
        "level_title": level_title(level),
        "level_xp": in_level,
        "level_need": need,
        "xp_pct": (in_level / need) if need else 0.0,
        "wins": wins,
        "games": games,
        "win_rate": round(wins / games * 100) if games else 0,
        "best_multiplier": data["best_multiplier"],
    }


def add_result(won: bool, multiplier: int) -> dict:
    """一局结束：AI 所在阵营赢则加经验，输只记场次。"""
    with _lock:
        data = _load()
        data["games"] += 1
        if won:
            data["wins"] += 1
            mult = max(1, int(multiplier))
            data["xp"] += WIN_XP_PER_MULTIPLIER * mult
            data["best_multiplier"] = max(data["best_multiplier"], mult)
        _save()
    return snapshot()
