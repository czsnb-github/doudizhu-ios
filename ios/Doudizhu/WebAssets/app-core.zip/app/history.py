"""对局历史：每局一个 JSON 文件落在 data/history/，超过容量上限从最旧的开始删。

默认上限 1GB，可用环境变量 DOUDIZHU_HISTORY_LIMIT_GB 调整。
文件名带毫秒时间戳和局号，按文件名排序即时间排序。
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
from datetime import datetime
from pathlib import Path

from .paths import DATA_DIR

log = logging.getLogger(__name__)

DIR = DATA_DIR / "history"
LIMIT_BYTES = int(float(os.environ.get("DOUDIZHU_HISTORY_LIMIT_GB", "1")) * 1_000_000_000)


def _prune(limit_bytes: int) -> int:
    """超过上限就从最旧的文件开始删，返回删掉的文件数。"""
    files = sorted(DIR.glob("*.json"))
    sizes: dict[Path, int] = {}
    total = 0
    for f in files:
        try:
            sizes[f] = f.stat().st_size
            total += sizes[f]
        except OSError:
            continue
    removed = 0
    for f in files:
        if total <= limit_bytes:
            break
        size = sizes.get(f)
        if size is None:
            continue
        try:
            f.unlink()
            total -= size
            removed += 1
            log.info("对局历史超限，删除最旧的 %s（- %.1f KB）", f.name, size / 1024)
        except OSError:
            log.exception("删除对局记录失败 %s", f.name)
    return removed


def record_game(payload: dict, limit_bytes: int | None = None, settle_id: str | None = None) -> Path | None:
    """把一局的结果写成历史文件；失败只记日志，不影响牌局。

    settle_id 幂等：同一局崩溃重启后重放不会写出重复牌谱。
    """
    try:
        DIR.mkdir(parents=True, exist_ok=True)
        suffix = ""
        if settle_id:
            payload = dict(payload)
            payload["settle_id"] = settle_id
            suffix = f"-{settle_id[:12]}"
            if list(DIR.glob(f"*{suffix}.json")):
                return None
        ts = datetime.now()
        name = f"{ts.strftime('%Y%m%d-%H%M%S')}-{ts.microsecond // 1000:03d}-r{int(payload.get('round') or 0):04d}{suffix}.json"
        path = DIR / name
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(path)
        _prune(LIMIT_BYTES if limit_bytes is None else int(limit_bytes))
        return path
    except Exception:
        log.exception("对局记录写入失败")
        return None


MAX_SYNC_RECORDS = 200


def _fingerprint(payload: dict) -> str:
    canonical = json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def export_records(limit: int = MAX_SYNC_RECORDS) -> list[dict]:
    """最近的对局原始记录，供端侧/服务端双向合并；按内容哈希去重。"""
    files = sorted(DIR.glob("*.json"), reverse=True)[: max(0, min(limit, 500))]
    rows = []
    for f in files:
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            log.exception("对局记录读取失败 %s", f.name)
            continue
        if isinstance(data, dict):
            rows.append(data)
    return rows


def merge_records(records, limit_bytes: int | None = None) -> int:
    """把另一台设备的对局记录并进来，按规范化 JSON 哈希去重。

    只接受字典、单条不超过 1MB、一次最多 500 条；坏数据跳过。返回新增条数。
    """
    if not isinstance(records, list):
        raise ValueError("对局记录格式不对")
    if len(records) > 500:
        raise ValueError("一次同步的对局记录太多了")
    known: set[str] = set()
    if DIR.exists():
        for f in DIR.glob("*.json"):
            try:
                old = json.loads(f.read_text(encoding="utf-8"))
            except Exception:
                continue
            if isinstance(old, dict):
                known.add(_fingerprint(old))
    added = 0
    try:
        DIR.mkdir(parents=True, exist_ok=True)
        for raw in records:
            if not isinstance(raw, dict):
                continue
            encoded = json.dumps(raw, ensure_ascii=False, separators=(",", ":"))
            if len(encoded.encode("utf-8")) > 1_000_000:
                continue
            fp = _fingerprint(raw)
            if fp in known:
                continue
            ts = datetime.now()
            text = str(raw.get("ended_at") or "").strip()
            if text:
                try:
                    parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
                    if parsed.tzinfo is not None:
                        parsed = parsed.astimezone().replace(tzinfo=None)
                    ts = parsed
                except ValueError:
                    pass
            try:
                round_no = int(raw.get("round") or 0)
            except (TypeError, ValueError):
                round_no = 0
            name = f"{ts.strftime('%Y%m%d-%H%M%S')}-{ts.microsecond // 1000:03d}-r{round_no:04d}-s{fp[:8]}.json"
            path = DIR / name
            if path.exists():
                path = DIR / f"{path.stem}-{fp[8:16]}.json"
            tmp = path.with_suffix(".json.tmp")
            tmp.write_text(
                json.dumps(raw, ensure_ascii=False, indent=1), encoding="utf-8"
            )
            tmp.replace(path)
            known.add(fp)
            added += 1
        if added:
            _prune(LIMIT_BYTES if limit_bytes is None else int(limit_bytes))
    except Exception:
        log.exception("对局记录合并失败")
        raise
    return added


def recent(limit: int = 20) -> list[dict]:
    """最近对局的摘要（不含牌谱）。"""
    files = sorted(DIR.glob("*.json"), reverse=True)[: max(0, min(limit, 100))]
    rows = []
    for f in files:
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            log.exception("对局记录读取失败 %s", f.name)
            continue
        rows.append({
            "file": f.name,
            "ended_at": d.get("ended_at"),
            "round": d.get("round"),
            "difficulty": d.get("difficulty"),
            "landlord": d.get("landlord"),
            "landlord_win": d.get("landlord_win"),
            "bid": d.get("bid"),
            "multiplier": d.get("multiplier"),
            "deltas": d.get("deltas"),
            "players": [p.get("name") for p in d.get("players", [])],
        })
    return rows
