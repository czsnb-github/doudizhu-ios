"""对局历史：每局一个 JSON 文件落在 data/history/，超过容量上限从最旧的开始删。

默认上限 1GB，可用环境变量 DOUDIZHU_HISTORY_LIMIT_GB 调整。
文件名带毫秒时间戳和局号，按文件名排序即时间排序。
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime
from pathlib import Path

from .paths import DATA_DIR

log = logging.getLogger(__name__)

DIR = DATA_DIR / "history"
LIMIT_BYTES = int(float(os.environ.get("DOUDIZHU_HISTORY_LIMIT_GB", "1")) * 1_000_000_000)


def _prune(limit_bytes: int) -> int:
    """超过上限就从最旧的文件开始删，返回删掉的文件数。"""
    files = sorted(DIR.glob("*.json"))
    sizes: dict[Path, int] = {}
    total = 0
    for f in files:
        try:
            sizes[f] = f.stat().st_size
            total += sizes[f]
        except OSError:
            continue
    removed = 0
    for f in files:
        if total <= limit_bytes:
            break
        size = sizes.get(f)
        if size is None:
            continue
        try:
            f.unlink()
            total -= size
            removed += 1
            log.info("对局历史超限，删除最旧的 %s（- %.1f KB）", f.name, size / 1024)
        except OSError:
            log.exception("删除对局记录失败 %s", f.name)
    return removed


def record_game(payload: dict, limit_bytes: int | None = None) -> Path | None:
    """把一局的结果写成历史文件；失败只记日志，不影响牌局。"""
    try:
        DIR.mkdir(parents=True, exist_ok=True)
        ts = datetime.now()
        name = f"{ts.strftime('%Y%m%d-%H%M%S')}-{ts.microsecond // 1000:03d}-r{int(payload.get('round') or 0):04d}.json"
        path = DIR / name
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(path)
        _prune(LIMIT_BYTES if limit_bytes is None else int(limit_bytes))
        return path
    except Exception:
        log.exception("对局记录写入失败")
        return None


def recent(limit: int = 20) -> list[dict]:
    """最近对局的摘要（不含牌谱）。"""
    files = sorted(DIR.glob("*.json"), reverse=True)[: max(0, min(limit, 100))]
    rows = []
    for f in files:
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            log.exception("对局记录读取失败 %s", f.name)
            continue
        rows.append({
            "file": f.name,
            "ended_at": d.get("ended_at"),
            "round": d.get("round"),
            "difficulty": d.get("difficulty"),
            "landlord": d.get("landlord"),
            "landlord_win": d.get("landlord_win"),
            "bid": d.get("bid"),
            "multiplier": d.get("multiplier"),
            "deltas": d.get("deltas"),
            "players": [p.get("name") for p in d.get("players", [])],
        })
    return rows
