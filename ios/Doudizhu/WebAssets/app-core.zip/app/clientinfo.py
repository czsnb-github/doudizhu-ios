"""客户端上报的屏幕/视口信息（只用于局域网内排查适配）。

浏览器在连接后主动上报；这里只保留白名单字段并做长度/范围限制，
避免一条异常消息把内存撑大。
"""

from __future__ import annotations

_TEXT_LIMITS = {
    "ua": 240,
    "platform": 60,
    "lang": 20,
    "orientation": 12,
}
_INT_FIELDS = (
    ("vw", 0, 20000),
    ("vh", 0, 20000),
    ("vvw", 0, 20000),
    ("vvh", 0, 20000),
    ("sw", 0, 20000),
    ("sh", 0, 20000),
    ("saw", 0, 20000),
    ("sah", 0, 20000),
    ("touch", 0, 20),
)


def _to_int(raw: dict, key: str, lo: int, hi: int) -> int | None:
    try:
        value = int(float(raw.get(key)))
    except (TypeError, ValueError, AttributeError):
        return None
    return max(lo, min(hi, value))


def clean_client_info(raw) -> dict:
    if not isinstance(raw, dict):
        return {}
    info: dict = {}
    for key, lo, hi in _INT_FIELDS:
        value = _to_int(raw, key, lo, hi)
        if value is not None:
            info[key] = value
    try:
        dpr = float(raw.get("dpr"))
        info["dpr"] = round(max(1.0, min(10.0, dpr)), 2)
    except (TypeError, ValueError, AttributeError):
        pass
    for key, limit in _TEXT_LIMITS.items():
        value = raw.get(key)
        if isinstance(value, (str, int, float)):
            info[key] = str(value)[:limit]
    for key in ("coarse", "mobile"):
        value = raw.get(key)
        if isinstance(value, bool):
            info[key] = value
    return info
