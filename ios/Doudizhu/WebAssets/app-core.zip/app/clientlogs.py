"""客户端失败日志：iOS 原生/网页把启动失败、JS 错误和诊断信息传到家中服务器。

家庭局域网使用，不做账号鉴权；日志只落在本机 `data/clientlogs/`。
"""
from __future__ import annotations

import json
import logging
import re
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path

from .paths import DATA_DIR

log = logging.getLogger(__name__)

DIR = DATA_DIR / "clientlogs"
MAX_FILES = 200
MAX_BYTES = 20_000_000
MAX_PAYLOAD_BYTES = 1_500_000
_LOCK = threading.RLock()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _safe_name(text: str, limit: int = 32) -> str:
    text = re.sub(r"[^0-9A-Za-z_.-]+", "-", str(text or "")).strip("-")
    return (text or "device")[:limit]


def _prune() -> None:
    if not DIR.exists():
        return
    files = sorted(DIR.glob("*.json"), key=lambda p: p.stat().st_mtime)
    total = sum(p.stat().st_size for p in files)
    while files and (len(files) > MAX_FILES or total > MAX_BYTES):
        path = files.pop(0)
        try:
            total -= path.stat().st_size
            path.unlink()
        except OSError:
            log.exception("清理客户端日志失败 %s", path.name)


def store(payload: dict, remote: str = "") -> dict:
    if not isinstance(payload, dict):
        raise ValueError("日志格式不对")
    body = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    if len(body.encode("utf-8")) > MAX_PAYLOAD_BYTES:
        raise ValueError("日志太大")
    device = payload.get("device")
    if isinstance(device, dict):
        label = device.get("name") or device.get("id") or "device"
    else:
        label = "device"
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-%f")
    log_id = f"{stamp}-{_safe_name(label)}-{uuid.uuid4().hex[:6]}"
    doc = {
        "id": log_id,
        "received_at": _now(),
        "remote": str(remote or "")[:64],
        "payload": payload,
    }
    with _LOCK:
        DIR.mkdir(parents=True, exist_ok=True)
        path = DIR / f"{log_id}.json"
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
        tmp.replace(path)
        _prune()
    return {"stored": True, "id": log_id}


def list_logs(limit: int = 20) -> list[dict]:
    if not DIR.exists():
        return []
    files = sorted(DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    rows = []
    for path in files[: max(0, min(int(limit or 20), 100))]:
        try:
            doc = json.loads(path.read_text(encoding="utf-8"))
            payload = doc.get("payload") if isinstance(doc.get("payload"), dict) else {}
            events = payload.get("events") if isinstance(payload.get("events"), list) else []
            last = events[-1] if events else {}
            rows.append({
                "id": doc.get("id") or path.stem,
                "received_at": doc.get("received_at"),
                "remote": doc.get("remote"),
                "reason": payload.get("reason"),
                "device": payload.get("device"),
                "app": payload.get("app"),
                "web": payload.get("web"),
                "event_count": len(events),
                "last_event": last.get("event") if isinstance(last, dict) else None,
                "last_message": last.get("message") if isinstance(last, dict) else None,
            })
        except Exception:
            log.exception("读取客户端日志失败 %s", path.name)
    return rows


def read_log(log_id: str) -> dict | None:
    text = str(log_id or "")
    if not re.fullmatch(r"[0-9A-Za-z_.-]{1,160}", text):
        return None
    path = (DIR / f"{text}.json").resolve()
    try:
        if path.parent != DIR.resolve() or not path.is_file():
            return None
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        log.exception("读取客户端日志失败 %s", text)
        return None
