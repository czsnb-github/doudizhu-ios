"""一张公共牌桌：三个人，机器人补位，不需要房间号。"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import random
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from .ai.agent import ai
from .ai.bidding_ai import ValueBidder, choose_call, grab_decision
from . import aiprofile
from . import history
from .game.combos import PlayGen, get_combo
from .game.engine import Game, GameError
from .meta import (
    AVATAR_MAP,
    BOT_PERSONAS,
    DEFAULT_AVATAR,
    DIFFICULTIES,
    DIFFICULTY_LABELS,
    avatar_url,
)
from .profiles import ProfileError, ProfileStore, profiles

log = logging.getLogger(__name__)

ACTIVE_PHASES = ("bidding", "playing")

# 强难度的机器人用 DouZero-WP 估值叫地主；easy/normal 仍走轻量规则，
# 让“难度”这个档位继续有意义。
VALUE_BID_LEVELS = ("hard", "master")
_value_bidder = ValueBidder()

# 单次广播/发送最多等这么久，避免一个掉线/半挂的 iPad 把牌桌锁拖死
BROADCAST_TIMEOUT = 3.0
# AI 回合超过这么久没动作，看门狗会重新调度一次
AI_WATCHDOG_QUIET = 6.0
AI_WATCHDOG_INTERVAL = 2.5


@dataclass
class Seat:
    index: int
    name: str
    pid: str | None = None
    is_bot: bool = False
    autopilot: bool = False
    abandoned: bool = False
    score: int = 0
    avatar: str = DEFAULT_AVATAR
    ai_level: str = "normal"
    ready: bool = False


class Table:
    STATE_VERSION = 1
    # 全部掉线后等待多久才作废本局（页面刷新会在几秒内重连，不会触发）
    ABORT_OFFLINE_WAIT = float(os.environ.get("DOUDIZHU_ABORT_OFFLINE_WAIT", "90"))

    def __init__(self, store: ProfileStore | None = None,
                 state_path: str | Path | None = None):
        self.store = store or profiles
        self.seats: list[Seat | None] = [None, None, None]
        self.clients: dict[str, object] = {}
        self.difficulty = "normal"
        self.game: Game | None = None
        self.round_no = 0
        self.score_applied = True
        self.settle_id: str | None = None
        self.rewards: dict[int, dict] = {}
        self.lock = asyncio.Lock()
        self.version = 0
        self.last_active = time.time()
        self._last_action_at = time.time()
        self._tasks: set[asyncio.Task] = set()
        self._bot_cursor = 0
        self._offline_token = 0.0
        # 牌桌快照默认和玩家档案放在同一个数据目录（隔离 dev 时一起隔离）
        self.state_path = (
            Path(state_path) if state_path
            else Path(self.store.path).parent / "table.json"
        )
        self._restoring = True
        self._load_state()
        self._restoring = False

    # ---------------------------------------------------------------- helpers

    @property
    def phase(self) -> str:
        return self.game.phase if self.game else "waiting"

    @property
    def humans(self) -> list[Seat]:
        return [s for s in self.seats if s and not s.is_bot]

    @property
    def connected_humans(self) -> list[Seat]:
        return [s for s in self.humans if s.pid in self.clients]

    def _all_ready(self) -> bool:
        if self.phase in ACTIVE_PHASES or self.phase == "redeal":
            return False
        humans = self.humans
        if not humans:
            return False
        return all(seat.ready and seat.pid in self.clients for seat in humans)

    def _touch(self):
        self.version += 1
        self.last_active = time.time()
        self._save_state()

    # ------------------------------------------------------------ persistence

    def _state_payload(self) -> dict:
        seats = []
        for i, seat in enumerate(self.seats):
            if seat is None:
                seats.append(None)
                continue
            seats.append({
                "index": i,
                "name": seat.name,
                "pid": seat.pid,
                "is_bot": bool(seat.is_bot),
                "autopilot": bool(seat.autopilot),
                "abandoned": bool(seat.abandoned),
                "score": int(seat.score),
                "avatar": seat.avatar,
                "ai_level": seat.ai_level,
                "ready": bool(seat.ready),
            })
        return {
            "version": self.STATE_VERSION,
            "saved_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "difficulty": self.difficulty,
            "round_no": int(self.round_no),
            "score_applied": bool(self.score_applied),
            "settle_id": self.settle_id,
            "rewards": {str(k): v for k, v in self.rewards.items()},
            "seats": seats,
            "game": self.game.to_state() if self.game else None,
        }

    def _save_state(self):
        if self._restoring:
            return
        try:
            self.state_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.state_path.with_name(self.state_path.name + ".tmp")
            tmp.write_text(
                json.dumps(self._state_payload(), ensure_ascii=False, indent=1),
                encoding="utf-8",
            )
            os.replace(tmp, self.state_path)
        except Exception:
            log.exception("牌桌快照保存失败: %s", self.state_path)

    def _load_state(self):
        if not self.state_path.exists():
            return
        try:
            data = json.loads(self.state_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError("快照不是对象")

            difficulty = data.get("difficulty")
            if difficulty in DIFFICULTIES:
                self.difficulty = difficulty
            self.round_no = max(0, int(data.get("round_no") or 0))
            self.score_applied = bool(data.get("score_applied", True))
            settle_id = data.get("settle_id")
            self.settle_id = str(settle_id) if settle_id else None

            rewards = data.get("rewards")
            self.rewards = {}
            if isinstance(rewards, dict):
                for key, value in rewards.items():
                    if isinstance(value, dict):
                        try:
                            self.rewards[int(key)] = value
                        except (TypeError, ValueError):
                            continue

            raw_seats = data.get("seats")
            if isinstance(raw_seats, list):
                seats: list[Seat | None] = [None, None, None]
                for i in range(3):
                    raw = raw_seats[i] if i < len(raw_seats) else None
                    if not isinstance(raw, dict):
                        continue
                    is_bot = bool(raw.get("is_bot"))
                    avatar = raw.get("avatar")
                    if avatar not in AVATAR_MAP:
                        avatar = DEFAULT_AVATAR
                    ai_level = raw.get("ai_level")
                    if ai_level not in DIFFICULTIES:
                        ai_level = self.difficulty
                    pid = None if is_bot else raw.get("pid")
                    seats[i] = Seat(
                        index=i,
                        name=str(raw.get("name") or "摩尔")[:12],
                        pid=str(pid) if pid else None,
                        is_bot=is_bot,
                        autopilot=bool(raw.get("autopilot")),
                        abandoned=bool(raw.get("abandoned")),
                        score=int(raw.get("score") or 0),
                        avatar=avatar,
                        ai_level=ai_level,
                        ready=bool(raw.get("ready")),
                    )
                self.seats = seats

            raw_game = data.get("game")
            if raw_game:
                self.game = Game.from_state(raw_game)
            else:
                self.game = None

            log.info(
                "已恢复牌桌快照: 阶段=%s 局数=%s 玩家数=%s",
                self.phase, self.round_no, len(self.humans),
            )
        except Exception:
            log.exception("牌桌快照损坏，已备份并开新桌: %s", self.state_path)
            try:
                broken = self.state_path.with_name(
                    self.state_path.name + ".broken"
                )
                if self.state_path.exists() and not broken.exists():
                    self.state_path.replace(broken)
            except Exception:
                log.exception("备份损坏快照失败")
            self.seats = [None, None, None]
            self.game = None
            self.difficulty = "normal"
            self.round_no = 0
            self.score_applied = True
            self.settle_id = None
            self.rewards = {}

    async def resume(self):
        """服务启动后接着上次的牌局。

        牌局先停在原处，所有真人标记托管；托管只表示等人回来，
        AI 不会替真人出牌。恢复后主动 schedule 一次，避免重启后
        卡在机器人回合，等真人刷新才继续。
        """
        async with self.lock:
            if not self.game:
                self._last_action_at = time.time()
                return
            if self.game.phase in ACTIVE_PHASES:
                for seat in self.humans:
                    seat.autopilot = True
                    seat.abandoned = False
            else:
                # 重开服务后按牌桌现状重新准备，避免旧快照里的“已准备”直接开局
                for seat in self.humans:
                    seat.ready = False
            if self.game.result and not self.score_applied:
                self._settle_locked(self.game.result)
            elif self.game.result and self.settle_id:
                # 结算状态已落盘，但档案/牌谱副作用可能被崩溃打断：幂等补全，
                # 不重复加经验、不重复写牌谱，也不重建已持久化的奖励展示。
                self._apply_rewards(self.game.result, self.settle_id, rebuild_rewards=False)
            self._last_action_at = time.time()
            self._touch()
        self.schedule()

    def _seat_by_pid(self, pid: str) -> Seat | None:
        for seat in self.seats:
            if seat and not seat.is_bot and seat.pid == pid:
                return seat
        return None

    def _free_seat(self, seat: Seat):
        if self.seats[seat.index] is seat:
            self.seats[seat.index] = None

    def _prune_offline(self, exclude: str | None = None):
        if self.phase in ACTIVE_PHASES:
            return
        for seat in list(self.seats):
            if not seat or seat.is_bot:
                continue
            if seat.pid == exclude:
                continue
            if seat.pid not in self.clients or seat.abandoned:
                self._free_seat(seat)

    def _next_persona(self) -> dict:
        used = {(s.name, s.avatar) for s in self.seats if s}
        for _ in range(len(BOT_PERSONAS) * 2):
            persona = BOT_PERSONAS[self._bot_cursor % len(BOT_PERSONAS)]
            self._bot_cursor += 1
            if (persona["name"], persona["avatar"]) not in used:
                return persona
        return {"name": f"小摩尔{random.randint(10, 99)}", "avatar": "mole_6"}

    def _add_bot(self, index: int) -> Seat:
        persona = self._next_persona()
        seat = Seat(
            index=index,
            name=persona["name"],
            is_bot=True,
            avatar=persona["avatar"],
            ai_level=self.difficulty,
            score=0,
            ready=True,
        )
        self.seats[index] = seat
        return seat

    def _fill_bots(self):
        for i in range(3):
            if self.seats[i] is None:
                self._add_bot(i)

    def _seat_to_bot(self, seat: Seat) -> Seat:
        """把主动离开的真人座位立刻换成机器人，避免另外两家卡死。

        分数留在座位上；这一局不再给离开的人记经验。
        """
        persona = self._next_persona()
        bot = Seat(
            index=seat.index,
            name=persona["name"],
            is_bot=True,
            avatar=persona["avatar"],
            ai_level=self.difficulty,
            score=seat.score,
            ready=True,
        )
        self.seats[seat.index] = bot
        return bot

    def _has_open_seat(self) -> bool:
        return any(s is None or s.is_bot for s in self.seats)

    def _claim_seat(self, pid: str, profile: dict) -> Seat | None:
        self._prune_offline(exclude=pid)
        index = next((i for i, s in enumerate(self.seats) if s is None), None)
        if index is None:
            index = next(
                (i for i, s in enumerate(self.seats) if s and s.is_bot), None
            )
        if index is None:
            return None
        old = self.seats[index]
        seat = Seat(
            index=index,
            pid=pid,
            name=profile["id"],
            avatar=profile["avatar"],
            score=old.score if old else 0,
        )
        self.seats[index] = seat
        return seat

    def _seat_view(self, index: int, seat: Seat | None, you: int | None) -> dict | None:
        if seat is None:
            return None
        connected = True if seat.is_bot else seat.pid in self.clients
        viewer = self.seats[you] if you is not None else None
        can_kick = bool(
            viewer
            and not viewer.is_bot
            and index != you
            and not seat.is_bot
            and (seat.autopilot or seat.abandoned or not connected)
        )
        data = {
            "seat": index,
            "name": seat.name,
            "pid": seat.pid,
            "is_bot": seat.is_bot,
            "connected": connected,
            "autopilot": seat.autopilot,
            "abandoned": seat.abandoned,
            "ready": bool(seat.ready),
            "can_kick": can_kick,
            "score": seat.score,
            "avatar": seat.avatar,
            "avatar_url": avatar_url(seat.avatar),
            "is_me": index == you,
            "ai_level": seat.ai_level if seat.is_bot else None,
            "ai_label": DIFFICULTY_LABELS.get(seat.ai_level) if seat.is_bot else None,
        }
        if not seat.is_bot and seat.pid:
            profile = self.store.snapshot(seat.pid)
            if profile:
                data["level"] = profile["level"]
                data["level_title"] = profile["level_title"]
                data["ram"] = profile["ram"]
                games = int(profile.get("games") or 0)
                data["wins"] = int(profile.get("wins") or 0)
                data["games"] = games
                data["win_rate"] = round(data["wins"] / games * 100) if games else 0
            reward = self.rewards.get(index)
            if reward and reward.get("pid") == seat.pid:
                data["reward"] = reward
        else:
            # 所有难度的机器人共用一个 AI 等级
            ai_prof = aiprofile.snapshot()
            data["level"] = ai_prof["level"]
            data["level_title"] = ai_prof["level_title"]
            data["xp"] = ai_prof["xp"]
            data["xp_pct"] = ai_prof["xp_pct"]
            data["level_xp"] = ai_prof["level_xp"]
            data["level_need"] = ai_prof["level_need"]
            data["wins"] = ai_prof["wins"]
            data["games"] = ai_prof["games"]
            data["win_rate"] = ai_prof["win_rate"]
            data["best_multiplier"] = ai_prof["best_multiplier"]
        return data

    def view(self, pid: str | None) -> dict:
        seat = self._seat_by_pid(pid) if pid else None
        you = seat.index if seat else None
        profile = self.store.snapshot(pid) if pid else None
        phase = self.phase
        return {
            "type": "state",
            "table": "庄园牌桌",
            "you": you,
            "me": profile,
            "spectator": you is None,
            "can_sit": (
                you is None
                and phase not in ACTIVE_PHASES
                and self._has_open_seat()
            ),
            "can_start": you is not None and self._all_ready(),
            "can_ready": you is not None and phase not in ACTIVE_PHASES,
            "all_ready": self._all_ready(),
            "ready_count": sum(1 for s in self.humans if s.ready),
            "human_count": len(self.humans),
            "difficulty": self.difficulty,
            "difficulty_label": DIFFICULTY_LABELS[self.difficulty],
            "round": self.round_no,
            "phase": phase,
            "seats": [self._seat_view(i, s, you) for i, s in enumerate(self.seats)],
            "game": self.game.view_for(you) if self.game else None,
            "rewards": list(self.rewards.values()),
            "online": len(self.clients),
            "ts": time.time(),
        }

    # ----------------------------------------------------------------- life

    async def attach(self, pid: str, ws) -> Seat | None:
        profile = self.store.snapshot(pid)
        if profile is None:
            raise ProfileError("玩家不存在")
        async with self.lock:
            self.clients[pid] = ws
            self._offline_token = time.time()
            seat = self._seat_by_pid(pid)
            if seat:
                seat.autopilot = False
                seat.abandoned = False
                seat.name = profile["id"]
                seat.avatar = profile["avatar"]
            elif self.phase in ACTIVE_PHASES:
                # 牌局进行中，新来的人只能观战：不能顶掉正在打牌的机器人座位
                seat = None
            else:
                seat = self._claim_seat(pid, profile)
            self._touch()
            await self.broadcast()
            self.schedule()
            return seat

    async def detach(self, pid: str, ws):
        async with self.lock:
            if self.clients.get(pid) is not ws:
                return
            del self.clients[pid]
            seat = self._seat_by_pid(pid)
            if seat:
                if self.phase in ACTIVE_PHASES:
                    seat.autopilot = True
                else:
                    self._free_seat(seat)
                    self._try_autostart()
            self._touch()
            await self.broadcast()
            self.schedule()
            # 没有在线真人后若长时间无人回来，作废本局让牌桌重开（刷新页面不会触发）。
            # 用 connected_humans 而非 clients：在线观战者不应阻止作废。
            self._arm_offline_abort()

    def _arm_offline_abort(self):
        if self.phase in ACTIVE_PHASES and not self.connected_humans:
            token = time.time()
            self._offline_token = token
            self._spawn(self._delayed_offline_abort(token))

    async def leave(self, pid: str):
        async with self.lock:
            self.clients.pop(pid, None)
            seat = self._seat_by_pid(pid)
            if seat:
                if self.phase in ACTIVE_PHASES:
                    # 主动离开和掉线不同：立刻换机器人接位，另外两家不用干等。
                    self._seat_to_bot(seat)
                    if not self.humans:
                        # 全部真人都退出了：作废本局，清空牌桌允许重开
                        self._abort_game()
                else:
                    self._free_seat(seat)
                    self._try_autostart()
            self._touch()
            await self.broadcast()
            self.schedule()
            # 还剩托管/掉线真人座位时也要武装离线作废，否则牌桌会永久卡住。
            self._arm_offline_abort()

    def _abort_game(self):
        """作废进行中的牌局，清空牌桌回到候场（不结算、不留历史）。"""
        self.game = None
        self.seats = [None, None, None]
        self.rewards = {}
        self.score_applied = True
        self.settle_id = None
        self.round_no = 0
        log.info("全员退出，本局作废，牌桌已重开")

    async def _delayed_offline_abort(self, token: float):
        await asyncio.sleep(self.ABORT_OFFLINE_WAIT)
        async with self.lock:
            if token != self._offline_token:
                return
            if not self.game or self.phase not in ACTIVE_PHASES:
                return
            if self.connected_humans:
                return
            self._abort_game()
            await self.broadcast()

    async def sit(self, pid: str):
        profile = self.store.snapshot(pid)
        if profile is None:
            raise ProfileError("玩家不存在")
        async with self.lock:
            if self.phase in ACTIVE_PHASES:
                raise GameError("这一局已经开始啦，等下一局再入座")
            if self._seat_by_pid(pid):
                raise GameError("你已经在座位上了")
            seat = self._claim_seat(pid, profile)
            if seat is None:
                raise GameError("牌桌已经坐满了")
            self._touch()
            await self.broadcast()

    async def set_difficulty(self, pid: str, level: str):
        if level not in DIFFICULTIES:
            raise GameError("未知的 AI 强度")
        async with self.lock:
            if not self._seat_by_pid(pid):
                raise GameError("先入座再调整 AI 强度")
            if self.phase in ACTIVE_PHASES:
                raise GameError("牌局进行中，等这一局结束再调整")
            self.difficulty = level
            for seat in self.seats:
                if seat and seat.is_bot:
                    seat.ai_level = level
            self._touch()
            await self.broadcast()

    async def update_profile(self, pid: str, data: dict):
        avatar = data.get("avatar")
        ram_color = data.get("ram_color")
        ram_name = data.get("ram_name")
        profile = self.store.update(
            pid,
            avatar=str(avatar) if avatar is not None else None,
            ram_color=str(ram_color) if ram_color is not None else None,
            ram_name=str(ram_name) if ram_name is not None else None,
        )
        async with self.lock:
            seat = self._seat_by_pid(pid)
            if seat:
                seat.avatar = profile["avatar"]
                seat.name = profile["id"]
            self._touch()
            await self.broadcast()
        return profile

    # ------------------------------------------------------------ game cycle

    def _try_autostart(self) -> bool:
        """所有在位真人都准备好了才开局；机器人不用准备。"""
        if not self._all_ready():
            return False
        return self._start_locked()

    def _start_locked(self) -> bool:
        if self.phase in ACTIVE_PHASES or self.phase == "redeal":
            return False
        self._prune_offline()
        if not self.connected_humans:
            return False
        self._fill_bots()
        self.round_no += 1
        self.game = Game(first_caller=(self.round_no - 1) % 3)
        self._last_action_at = time.time()
        self.score_applied = False
        self.settle_id = None
        self.rewards = {}
        for s in self.seats:
            if not s:
                continue
            if s.is_bot:
                s.ai_level = self.difficulty
                s.ready = True
            else:
                s.ready = False
        return True

    async def set_ready(self, pid: str, ready: bool = True):
        async with self.lock:
            if self.phase == "redeal":
                raise GameError("正在重新发牌，稍等一下")
            if self.phase in ACTIVE_PHASES:
                raise GameError("这一局已经开始啦")
            seat = self._seat_by_pid(pid)
            if seat is None:
                raise GameError("先入座再准备")
            seat.ready = bool(ready)
            self._try_autostart()
            self._touch()
            await self.broadcast()
            self.schedule()

    async def start_game(self, pid: str):
        # 兼容旧接口：当作“我准备好了”，凑齐所有真人后自动开局
        await self.set_ready(pid, True)

    async def kick(self, pid: str, target_pid: str):
        """把托管/掉线的真人请离，座位交给机器人，牌局不卡住。"""
        async with self.lock:
            actor = self._seat_by_pid(pid)
            if actor is None:
                raise GameError("先入座才能管理牌桌")
            target = self._seat_by_pid(target_pid)
            if target is None or target.is_bot:
                raise GameError("这个座位不能请离")
            if target.index == actor.index:
                raise GameError("不能请离自己")
            connected = target.pid in self.clients
            if not (target.autopilot or target.abandoned or not connected):
                raise GameError("只有托管或离线的玩家可以请离")
            target_id = target.pid
            target_name = target.name
            if self.phase in ACTIVE_PHASES:
                self._seat_to_bot(target)
            else:
                self._free_seat(target)
            self._try_autostart()
            self._touch()
            await self.broadcast()
            ws = self.clients.get(target_id) if target_id else None
            if ws:
                try:
                    await ws.send_json({
                        "type": "kicked",
                        "by": actor.name,
                        "message": f"你被 {actor.name} 请离了牌桌，可以继续观战",
                    })
                except Exception:
                    pass
            self.schedule()
            return target_name

    async def update_settings(self, pid: str, data: dict):
        if not isinstance(data, dict):
            raise GameError("设置格式不对")
        profile = self.store.update_settings(pid, data)
        async with self.lock:
            self._touch()
            await self.broadcast()
        return profile

    async def grab(self, pid: str, want: bool):
        async with self.lock:
            seat = self._seat_by_pid(pid)
            if seat is None:
                raise GameError("你现在是观众，先入座吧")
            g = self.game
            if g is None or not g.grab_active:
                raise GameError("当前不是抢地主阶段")
            assert seat
            g.grab(seat.index, bool(want))
            self._after_action()
            await self.broadcast()
            self.schedule()

    async def call(self, pid: str, want: bool):
        async with self.lock:
            seat = self._require_turn(pid, calling=True)
            assert self.game and seat
            self.game.call(seat.index, bool(want))
            self._after_action()
            await self.broadcast()
            self.schedule()

    async def play(self, pid: str, cards: list[int]):
        async with self.lock:
            seat = self._require_turn(pid)
            assert self.game and seat
            self.game.play(seat.index, cards)
            self._after_action()
            await self.broadcast()
            self.schedule()

    async def pass_turn(self, pid: str):
        async with self.lock:
            seat = self._require_turn(pid)
            assert self.game and seat
            self.game.pass_turn(seat.index)
            self._after_action()
            await self.broadcast()
            self.schedule()

    async def hint(self, pid: str) -> list[list[int]]:
        async with self.lock:
            seat = self._require_turn(pid)
            assert self.game and seat
            g = self.game
            gen = PlayGen(g.hands[seat.index])
            plays = gen.beats(g.last_combo) if g.last_combo else gen.all()
            plays = [p for p in plays if p]

            def key(p):
                combo = get_combo(p)
                bomb = 1 if combo and combo.type in ("bomb", "rocket") else 0
                return (bomb, len(p), combo.main if combo else 0)

            plays.sort(key=key)
            return plays[:40]

    def _require_turn(self, pid: str, *, calling: bool = False) -> Seat:
        seat = self._seat_by_pid(pid)
        if seat is None:
            raise GameError("你现在是观众，先入座吧")
        g = self.game
        if g is None:
            raise GameError("还没有开始游戏")
        if calling:
            if (
                g.phase != "bidding"
                or g.grab_active
                or seat.index != g.call_turn
            ):
                raise GameError("还没轮到你叫地主")
        elif g.phase != "playing" or seat.index != g.current:
            raise GameError("还没轮到你出牌")
        return seat

    # -------------------------------------------------------------- internals

    def _after_action(self):
        self._last_action_at = time.time()
        g = self.game
        if g and g.result and not self.score_applied:
            self._settle_locked(g.result)
        self._touch()

    def _settle_locked(self, result: dict):
        """结算一局的座位分与奖励。调用方已持锁。

        先把 score_applied/settle_id/座位分落盘，再写档案与牌谱副作用；
        崩溃重启后 resume() 凭 settle_id 幂等补全，不会重复加经验或重复牌谱。
        """
        for s, delta in zip(self.seats, result["deltas"]):
            if s:
                s.score += delta
        self.settle_id = self.settle_id or uuid.uuid4().hex
        self.score_applied = True
        self._touch()
        self._apply_rewards(result, self.settle_id, rebuild_rewards=True)

    def _apply_rewards(self, result: dict, settle_id: str | None = None, rebuild_rewards: bool = True):
        landlord = result["landlord"]
        landlord_win = bool(result["landlord_win"])
        multiplier = int(result["multiplier"])
        ai_won = False
        for index, seat in enumerate(self.seats):
            if not seat or seat.is_bot or not seat.pid:
                continue
            won = (index == landlord and landlord_win) or (
                index != landlord and not landlord_win
            )
            try:
                reward = self.store.record_result(
                    seat.pid, won=won, multiplier=multiplier, settle_id=settle_id
                )
            except Exception:
                log.exception("结算玩家 %s 失败", seat.pid)
                continue
            if rebuild_rewards:
                reward.update(
                    {"seat": index, "pid": seat.pid, "name": seat.name}
                )
                self.rewards[index] = reward
        # 所有难度的机器人共用一个 AI 等级：只要赢的一方里有 AI，就算 AI 赢
        for seat in self.seats:
            if not seat or not seat.is_bot:
                continue
            index = seat.index
            won = (index == landlord and landlord_win) or (
                index != landlord and not landlord_win
            )
            if won:
                ai_won = True
                break
        try:
            aiprofile.add_result(won=ai_won, multiplier=multiplier, settle_id=settle_id)
        except Exception:
            log.exception("AI 档案结算失败")
        # 对局历史落盘（超过容量上限自动删最旧的）
        try:
            history.record_game({
                "version": 2,
                "ended_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "round": self.round_no,
                "difficulty": self.difficulty,
                "landlord": landlord,
                "landlord_win": landlord_win,
                "caller": result.get("caller"),
                "multiplier": multiplier,
                "bombs": result.get("bombs"),
                "grabs": result.get("grabs"),
                "spring": result.get("spring"),
                "anti_spring": result.get("anti_spring"),
                "total": result.get("total"),
                "deltas": result.get("deltas"),
                "bottom": result.get("bottom"),
                "hands": result.get("hands"),
                "calls": list(self.game.calls) if self.game else None,
                "actions": [list(x) for x in (self.game.action_seq if self.game else [])],
                "players": [
                    {
                        "seat": i,
                        "pid": s.pid,
                        "name": s.name,
                        "is_bot": s.is_bot,
                        "avatar": s.avatar,
                        "ai_level": s.ai_level if s.is_bot else None,
                    }
                    for i, s in enumerate(self.seats)
                    if s
                ],
            }, settle_id=settle_id)
        except Exception:
            log.exception("对局历史记录失败")

    def _ai_seat(self) -> int | None:
        g = self.game
        if not g:
            return None
        if g.phase == "bidding":
            index = g.grab_turn if g.grab_active else g.call_turn
        elif g.phase == "playing":
            index = g.current
        else:
            return None
        if index is None:
            return None
        seat = self.seats[index]
        # 只让真机器人行动。掉线/托管的真人牌权停住，等他回来自己打。
        if seat and seat.is_bot:
            return index
        return None

    def schedule(self):
        if not self.game:
            return
        if self.game.phase == "redeal":
            ver = self.version
            self._spawn(self._delayed_redeal(ver))
            return
        index = self._ai_seat()
        if index is None:
            return
        ver = self.version
        self._spawn(self._delayed_ai(ver, index))

    def _spawn(self, coro):
        task = asyncio.create_task(coro)
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def _delayed_ai(self, ver: int, index: int):
        await asyncio.sleep(0.55 + random.random() * 0.45)
        async with self.lock:
            if ver != self.version or not self.game:
                # 版本在等待期间变了（有人重连/刷新），不能把机器人的回合丢掉
                self.schedule()
                return
            if self._ai_seat() != index:
                self.schedule()
                return
            g = self.game
            seat = self.seats[index]
            level = self.difficulty
            if seat and seat.is_bot:
                level = seat.ai_level
            if g.grab_active:
                level_eff = level
                value = None
                if level_eff in VALUE_BID_LEVELS and ai.available:
                    value = await asyncio.to_thread(
                        _value_bidder.landlord_value, g.hands[index], index
                    )
                want = grab_decision(
                    g.hands[index],
                    index,
                    level_eff,
                    value=value,
                    reback=index == g.caller,
                    rng=random,
                )
                g.grab(index, want)
            elif g.phase == "bidding":
                is_last = all(
                    g.calls[s] is False for s in range(3) if s != index
                )
                if seat is not None and seat.is_bot and level in VALUE_BID_LEVELS and ai.available:
                    want = await asyncio.to_thread(
                        _value_bidder.should_call, g.hands[index], index
                    )
                else:
                    want = choose_call(
                        g.hands[index], level, is_last=is_last, rng=random
                    )
                g.call(index, want)
            elif g.phase == "playing":
                try:
                    action = await asyncio.to_thread(
                        ai.choose, g.clone(), index, level
                    )
                except Exception:
                    log.exception("AI 计算失败")
                    action = []
                try:
                    g.play(index, action)
                except GameError:
                    try:
                        g.pass_turn(index)
                    except GameError:
                        g.play(index, [g.hands[index][0]])
            self._after_action()
            await self.broadcast()
            self.schedule()

    async def _delayed_redeal(self, ver: int):
        await asyncio.sleep(1.5)
        async with self.lock:
            if not self.game:
                return
            if ver != self.version:
                # 等待期间有人入座/改设置等 bumped version；重新排程，别卡在 redeal。
                self.schedule()
                return
            if self.game.phase != "redeal":
                return
            self.round_no += 1
            self.game = Game(first_caller=(self.round_no - 1) % 3)
            self.score_applied = False
            self.settle_id = None
            self.rewards = {}
            self._touch()
            await self.broadcast()
            self.schedule()

    # ----------------------------------------------------------------- output

    async def broadcast(self):
        async def send(pid, ws):
            try:
                await asyncio.wait_for(
                    ws.send_json(self.view(pid)), timeout=BROADCAST_TIMEOUT
                )
            except asyncio.TimeoutError:
                log.warning("广播超时，断开客户端 pid=%s", pid)
                try:
                    await ws.close()
                except Exception:
                    pass
            except Exception:
                log.debug("发送失败 pid=%s", pid)

        await asyncio.gather(*(send(pid, ws) for pid, ws in list(self.clients.items())))

    async def send_to(self, pid: str):
        ws = self.clients.get(pid)
        if ws:
            try:
                await asyncio.wait_for(
                    ws.send_json(self.view(pid)), timeout=BROADCAST_TIMEOUT
                )
            except Exception:
                pass

    async def watchdog(self):
        """兜底：机器人回合超过 AI_WATCHDOG_QUIET 秒没人动，就重新 schedule。

        正常 AI 推理很快；这里只处理任务被版本切换吞掉、广播卡住等异常。
        """
        while True:
            await asyncio.sleep(AI_WATCHDOG_INTERVAL)
            try:
                async with self.lock:
                    if not self.game or self.game.phase not in ACTIVE_PHASES:
                        continue
                    index = self._ai_seat()
                    if index is None:
                        continue
                    idle = time.time() - self._last_action_at
                    if idle < AI_WATCHDOG_QUIET:
                        continue
                    log.warning("AI 回合 %.1fs 未行动，看门狗重新调度 seat=%s", idle, index)
                    self.schedule()
            except asyncio.CancelledError:
                raise
            except Exception:
                log.exception("AI 看门狗异常")


table = Table()
