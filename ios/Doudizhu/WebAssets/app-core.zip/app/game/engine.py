"""一局斗地主的状态机: 发牌、叫地主/抢地主、出牌、计分。

叫地主对齐欢乐斗地主基础模式：
- 按次序轮流“叫地主 / 不叫”，都不叫则重新发牌；
- 有人叫地主后，其余未叫过“不叫”的玩家各有一次“抢地主”机会；
- 若有人抢，叫地主者还有一次“抢回”机会；最后抢的人当地主；
- 每抢一次倍数 ×2，叫地主本身不额外加倍。
"""

from __future__ import annotations

import copy
import random
from collections import Counter
from types import SimpleNamespace

from ..cards import FULL_DECK, deal, rank, sort_cards, to_dz
from .combos import Combo, PlayGen, can_beat, deduce, get_combo

BASE_SCORE = 100
POSITIONS = ("landlord", "landlord_down", "landlord_up")


class GameError(Exception):
    pass


class Game:
    def __init__(self, first_caller: int = 0, deck: list[int] | None = None):
        self.hands, self.bottom = deal(deck)
        self.phase = "bidding"           # bidding / playing / ended / redeal
        self.first_caller = first_caller % 3
        self.call_turn = self.first_caller
        self.calls = [None, None, None]  # True=叫地主 False=不叫 None=还没表态
        self.caller: int | None = None
        self.grab_active = False
        self.grab_candidate: int | None = None
        self.grab_queue: list[int] = []
        self.grab_turn: int | None = None
        self.grab_acted: list[int] = []
        self.grabs = 0
        self.landlord: int | None = None
        self.current: int | None = None
        self.bottom_revealed = False
        self.last_combo: Combo | None = None
        self.last_combo_cards: list[int] = []
        self.last_play_seat: int | None = None
        self.passes = 0
        self.played = [[], [], []]
        self.last_action = [[], [], []]
        self.action_seq: list[list[int]] = []
        self.bomb_count = 0
        self.landlord_plays = 0
        self.farmer_plays = 0
        self.result: dict | None = None
        self.seq = 0
        self.event: dict | None = {"type": "deal"}
        self.multiplier = 1
        self.highlight = None

    # ------------------------------------------------------------------ helpers

    @property
    def counts(self) -> list[int]:
        return [len(h) for h in self.hands]

    def position_of(self, seat: int | None = None) -> str:
        seat = self.current if seat is None else seat
        assert self.landlord is not None and seat is not None
        if seat == self.landlord:
            return "landlord"
        if seat == (self.landlord + 1) % 3:
            return "landlord_down"
        return "landlord_up"

    def seat_of(self, position: str) -> int:
        assert self.landlord is not None
        if position == "landlord":
            return self.landlord
        if position == "landlord_down":
            return (self.landlord + 1) % 3
        return (self.landlord + 2) % 3

    def _bump(self, event: dict):
        self.seq += 1
        event["seq"] = self.seq
        self.event = event

    def clone(self) -> "Game":
        return copy.deepcopy(self)

    # ------------------------------------------------------------- persistence

    _STATE_FIELDS = (
        "phase", "first_caller", "call_turn", "calls", "caller",
        "landlord", "current", "bottom_revealed",
        "last_combo_cards", "last_play_seat", "passes", "played",
        "last_action", "action_seq", "bomb_count", "landlord_plays",
        "farmer_plays", "result", "seq", "event", "multiplier", "highlight",
        "grab_active", "grab_candidate", "grab_queue", "grab_turn",
        "grab_acted", "grabs",
    )

    def to_state(self) -> dict:
        """可 JSON 序列化的完整牌局状态（含三家手牌，服务端私有）。"""
        state = {
            "hands": [list(h) for h in self.hands],
            "bottom": list(self.bottom),
            "last_combo": self.last_combo.to_json() if self.last_combo else None,
        }
        for name in self._STATE_FIELDS:
            state[name] = copy.deepcopy(getattr(self, name))
        return state

    @classmethod
    def from_state(cls, data: dict) -> "Game":
        """从快照恢复；结构不合法时抛 ValueError，由调用方决定是否放弃。"""
        if not isinstance(data, dict):
            raise ValueError("牌局快照不是对象")
        phase = data.get("phase")
        if phase not in ("bidding", "playing", "ended", "redeal"):
            raise ValueError(f"未知阶段: {phase!r}")

        hands = data.get("hands")
        if not isinstance(hands, list) or len(hands) != 3:
            raise ValueError("手牌数量不对")
        clean_hands = []
        for hand in hands:
            if not isinstance(hand, list):
                raise ValueError("手牌格式不对")
            cards = [int(c) for c in hand]
            if any(c < 0 or c > 53 for c in cards):
                raise ValueError("手牌超出范围")
            clean_hands.append(sort_cards(cards))

        bottom = data.get("bottom")
        if not isinstance(bottom, list):
            raise ValueError("底牌格式不对")
        bottom_cards = [int(c) for c in bottom]
        if len(bottom_cards) != 3:
            raise ValueError("底牌数量不对")

        g = cls.__new__(cls)
        for name in cls._STATE_FIELDS:
            setattr(g, name, copy.deepcopy(data.get(name)))
        g.hands = clean_hands
        g.bottom = bottom_cards
        g.calls = (
            list(g.calls)
            if isinstance(g.calls, list) and len(g.calls) == 3
            else [None, None, None]
        )
        g.calls = [
            None if v is None else bool(v)
            for v in g.calls
        ]
        if "calls" not in data and phase == "bidding":
            # 旧版叫分快照：规则已经变了，直接重发一局，别让牌桌卡住
            g.phase = "redeal"
            g.call_turn = None
            g.event = {"type": "redeal", "seq": g.seq or 0}
        if g.grab_active is None:
            g.grab_active = False
        g.grab_queue = [int(s) % 3 for s in (g.grab_queue or []) if isinstance(s, int)]
        g.grab_acted = [int(s) % 3 for s in (g.grab_acted or []) if isinstance(s, int)]
        if g.grabs is None:
            g.grabs = 0
        for name in ("caller", "call_turn", "first_caller", "landlord", "current"):
            value = getattr(g, name)
            if value is not None:
                setattr(g, name, int(value) % 3)
        if g.first_caller is None:
            g.first_caller = 0
        if g.caller is None and g.landlord is not None:
            # 旧快照或从出牌阶段恢复：叫地主者信息缺失，不影响继续打
            g.caller = g.landlord
        g.played = [list(x) for x in (g.played or [[], [], []])]
        g.last_action = [list(x) for x in (g.last_action or [[], [], []])]
        g.action_seq = [list(x) for x in (g.action_seq or [])]
        g.last_combo_cards = list(g.last_combo_cards or [])
        if g.passes is None:
            g.passes = 0
        if g.bomb_count is None:
            g.bomb_count = 0
        if g.multiplier is None:
            g.multiplier = 1
        if g.seq is None:
            g.seq = 0
        g.last_combo = (
            get_combo(g.last_combo_cards) if g.last_combo_cards else None
        )
        # 连续三张的"纯飞机 vs 飞机带翅膀"有二义性：出牌时按上家牌型解析出的
        # type 已存进快照，恢复时优先采用，避免重启后把 plane1 误读成 plane。
        saved_combo = data.get("last_combo")
        if g.last_combo_cards and isinstance(saved_combo, dict):
            want = saved_combo.get("type")
            if want in ("plane1", "plane2"):
                alt = get_combo(g.last_combo_cards, skip_pure_plane=True)
                if (alt is not None and alt.type == want
                        and alt.main == saved_combo.get("main")
                        and alt.length == saved_combo.get("length")):
                    g.last_combo = alt
        if g.last_combo_cards and g.last_combo is None:
            # 快照里的“上家牌型”已经对不上，宁可不恢复也不带病继续
            raise ValueError("上家牌型与出牌记录不一致")
        return g

    # ------------------------------------------------------------------ bidding

    def call(self, seat: int, want: bool):
        """叫地主 / 不叫。第一个叫地主的人成为待抢地主。"""
        if self.phase != "bidding" or self.grab_active:
            raise GameError("当前不是叫地主阶段")
        if seat != self.call_turn:
            raise GameError("还没轮到你叫地主")
        want = bool(want)
        self.calls[seat] = want
        if want:
            self.caller = seat
            self.grab_candidate = seat
            self.grab_active = True
            self.grab_acted = []
            self.grabs = 0
            # 其余两家按次序各有一次抢地主机会；明确“不叫”的人没有抢权
            self.grab_queue = [
                s for s in ((seat + 1) % 3, (seat + 2) % 3)
                if self.calls[s] is not False
            ]
            self._bump({"type": "call", "seat": seat, "want": True})
            if self.grab_queue:
                self.grab_turn = self.grab_queue[0]
                self._bump({
                    "type": "grab_start",
                    "caller": seat,
                    "candidate": seat,
                    "turn": self.grab_turn,
                })
            else:
                self._finish_grabbing()
            return

        self._bump({"type": "call", "seat": seat, "want": False})
        if all(c is False for c in self.calls):
            self.phase = "redeal"
            self.call_turn = None
            self._bump({"type": "redeal"})
            return
        self.call_turn = (seat + 1) % 3

    def grab(self, seat: int, want: bool):
        """抢地主/不抢。每人只有一次机会；不叫过的人没有抢权。

        其余两家都表态后，如果中间有人抢过，叫地主者还有一次“抢回”机会。
        """
        if self.phase != "bidding" or not self.grab_active:
            raise GameError("当前不是抢地主阶段")
        if seat != self.grab_turn:
            raise GameError("还没轮到你抢地主")
        want = bool(want)
        if seat not in self.grab_acted:
            self.grab_acted.append(seat)
        if want:
            self.grabs += 1
            self.grab_candidate = seat
            self._bump({"type": "grab", "seat": seat, "grabs": self.grabs})
        else:
            self._bump({"type": "pass_grab", "seat": seat})
        self.grab_queue = [s for s in self.grab_queue if s != seat]
        if self.grab_queue:
            self.grab_turn = self.grab_queue[0]
            return
        caller = self.caller
        if (
            self.grabs > 0
            and caller is not None
            and caller not in self.grab_acted
        ):
            # 叫地主者抢回：这是他唯一一次抢地主机会
            self.grab_queue = [caller]
            self.grab_turn = caller
            self._bump({
                "type": "grab_reback",
                "seat": caller,
                "candidate": self.grab_candidate,
            })
            return
        self._finish_grabbing()

    def _finish_grabbing(self):
        self.grab_active = False
        self.grab_turn = None
        self.grab_queue = []
        cand = self.grab_candidate
        assert cand is not None
        self.landlord = cand
        self.hands[cand] = sort_cards(self.hands[cand] + self.bottom)
        self.bottom_revealed = True
        self.phase = "playing"
        self.current = cand
        # 底分固定 100，叫地主不加倍；每抢一次 ×2
        self.multiplier = 2 ** self.grabs
        self._bump({
            "type": "landlord",
            "seat": cand,
            "caller": self.caller,
            "grabs": self.grabs,
            "bottom": list(self.bottom),
        })

    # ------------------------------------------------------------------ play

    def play(self, seat: int, cards: list[int]):
        if self.phase != "playing":
            raise GameError("当前不能出牌")
        if seat != self.current:
            raise GameError("还没轮到你出牌")
        cards = list(cards)
        if not cards:
            self.pass_turn(seat=seat)
            return
        ok, why, combo = deduce(self.hands[seat], cards, self.last_combo)
        if not ok:
            raise GameError(why)
        assert combo is not None
        for c in cards:
            self.hands[seat].remove(c)
        self.hands[seat].sort()
        self.played[seat].extend(cards)
        self.last_action[seat] = list(cards)
        self.action_seq.append(list(cards))
        self.last_combo = combo
        self.last_combo_cards = list(cards)
        self.last_play_seat = seat
        self.passes = 0
        if seat == self.landlord:
            self.landlord_plays += 1
        else:
            self.farmer_plays += 1
        if combo.type in ("bomb", "rocket"):
            self.bomb_count += 1
            self.multiplier *= 2
        self._bump({
            "type": "play",
            "seat": seat,
            "cards": list(cards),
            "combo": combo.label,
            "bomb": combo.type in ("bomb", "rocket"),
        })
        if not self.hands[seat]:
            self._finish(seat == self.landlord)
            return
        self.current = (seat + 1) % 3

    def pass_turn(self, seat: int | None = None):
        if self.phase != "playing":
            raise GameError("当前不能过牌")
        if seat is not None and seat != self.current:
            raise GameError("还没轮到你")
        if self.last_combo is None:
            raise GameError("你是先手，必须出牌")
        seat = self.current
        assert seat is not None
        self.last_action[seat] = []
        self.action_seq.append([])
        self.passes += 1
        self._bump({"type": "pass", "seat": seat})
        if self.passes >= 2:
            self.current = self.last_play_seat
            self.last_combo = None
            self.last_combo_cards = []
            self.passes = 0
            self._bump({"type": "trick", "seat": self.current})
        else:
            self.current = (seat + 1) % 3

    def _finish(self, landlord_win: bool):
        assert self.landlord is not None
        spring = landlord_win and self.farmer_plays == 0
        anti_spring = (not landlord_win) and self.landlord_plays == 1
        if spring or anti_spring:
            self.multiplier *= 2
        total = BASE_SCORE * self.multiplier
        deltas = [0, 0, 0]
        for s in range(3):
            if s == self.landlord:
                deltas[s] = 2 * total if landlord_win else -2 * total
            else:
                deltas[s] = -total if landlord_win else total
        self.phase = "ended"
        self.current = None
        self.result = {
            "landlord_win": landlord_win,
            "winner": "landlord" if landlord_win else "farmers",
            "landlord": self.landlord,
            "caller": self.caller,
            "bombs": self.bomb_count,
            "spring": spring,
            "anti_spring": anti_spring,
            "multiplier": self.multiplier,
            "grabs": self.grabs,
            "total": total,
            "deltas": deltas,
            "hands": [list(h) for h in self.hands],
            "bottom": list(self.bottom),
        }
        self._bump({
            "type": "end",
            "winner": "landlord" if landlord_win else "farmers",
            "spring": spring,
            "anti_spring": anti_spring,
            "deltas": deltas,
        })

    # ------------------------------------------------------------------ views

    def public_state(self) -> dict:
        return {
            "phase": self.phase,
            "first_caller": self.first_caller,
            "call_turn": (
                self.call_turn
                if self.phase == "bidding" and not self.grab_active
                else None
            ),
            "calls": list(self.calls),
            "caller": self.caller,
            "landlord": self.landlord,
            "current": self.current,
            "counts": self.counts,
            "bottom": list(self.bottom) if self.bottom_revealed else [],
            "bottom_hidden": 3 if not self.bottom_revealed else 0,
            "played": [list(x) for x in self.played],
            "last_action": [list(x) for x in self.last_action],
            "last_combo": self.last_combo.to_json() if self.last_combo else None,
            "last_combo_cards": list(self.last_combo_cards),
            "last_play_seat": self.last_play_seat,
            "passes": self.passes,
            "bomb_count": self.bomb_count,
            "multiplier": self.multiplier,
            "grab_active": self.grab_active,
            "grab_candidate": self.grab_candidate,
            "grab_turn": self.grab_turn if (self.phase == "bidding" and self.grab_active) else None,
            "grabs": self.grabs,
            "current_multiplier": (2 ** self.grabs) if self.caller is not None else 0,
            "result": self.result,
            "seq": self.seq,
            "event": self.event,
        }

    def view_for(self, seat: int | None) -> dict:
        st = self.public_state()
        st["your_seat"] = seat
        st["hand"] = list(self.hands[seat]) if seat is not None else []
        if self.landlord is not None:
            st["your_position"] = self.position_of(seat) if seat is not None else None
        else:
            st["your_position"] = None
        return st

    # ------------------------------------------------------------------ AI input

    def ai_input(self, seat: int):
        """构造 DouZero 所需 infoset 及可回到真实手牌的候选动作。"""
        assert self.landlord is not None
        hand = self.hands[seat]
        gen = PlayGen(hand)
        if self.last_combo is not None:
            physical = gen.beats(self.last_combo)
        else:
            physical = gen.all()
        if not physical:
            physical = [[]]
        dz_actions = [to_dz(p) for p in physical]

        my_dz = to_dz(hand)
        full = Counter(to_dz(FULL_DECK))
        for c in my_dz:
            full[c] -= 1
        for seat_cards in self.played:
            for c in to_dz(seat_cards):
                full[c] -= 1
        other = []
        for c, n in full.items():
            other.extend([c] * max(0, n))
        other.sort()

        last_move = to_dz(self.last_combo_cards) if self.last_combo is not None else []
        last_move_dict = {}
        played_dict = {}
        num_left = {}
        for pos in POSITIONS:
            s = self.seat_of(pos)
            last_move_dict[pos] = to_dz(self.last_action[s])
            played_dict[pos] = to_dz(self.played[s])
            num_left[pos] = len(self.hands[s])

        seq = [to_dz(x) for x in self.action_seq]
        infoset = SimpleNamespace(
            player_position=self.position_of(seat),
            player_hand_cards=sorted(my_dz),
            other_hand_cards=other,
            legal_actions=dz_actions,
            last_move=last_move,
            last_move_dict=last_move_dict,
            num_cards_left_dict=num_left,
            played_cards=played_dict,
            card_play_action_seq=seq,
            bomb_num=self.bomb_count,
            physical_actions=physical,
        )
        return infoset
