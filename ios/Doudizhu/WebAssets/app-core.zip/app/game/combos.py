"""牌型识别、大小比较与合法出牌生成。

牌型:
  single 单张 / pair 对子 / triple 三张 / triple1 三带一 / triple2 三带二
  straight 顺子 / pair_straight 连对 / plane 飞机(不带) / plane1 飞机带单
  plane2 飞机带对 / four2 四带二单 / four2pair 四带两对 / bomb 炸弹 / rocket 王炸
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from itertools import combinations, combinations_with_replacement

from ..cards import rank, sort_cards

TYPE_LABELS = {
    "single": "单张", "pair": "对子", "triple": "三张",
    "triple1": "三带一", "triple2": "三带二",
    "straight": "顺子", "pair_straight": "连对",
    "plane": "飞机", "plane1": "飞机带单", "plane2": "飞机带对",
    "four2": "四带二", "four2pair": "四带两对",
    "bomb": "炸弹", "rocket": "王炸",
}


@dataclass(frozen=True)
class Combo:
    type: str
    main: int
    length: int = 1
    cards: tuple[int, ...] = ()

    @property
    def label(self) -> str:
        if self.type in ("straight", "pair_straight", "plane", "plane1", "plane2"):
            return f"{TYPE_LABELS[self.type]}({self.length})"
        return TYPE_LABELS[self.type]

    def to_json(self) -> dict:
        return {"type": self.type, "label": self.label, "main": self.main, "length": self.length}


def _runs_of(triple_ranks: list[int], k: int):
    s = set(triple_ranks)
    for start in range(3, 15 - k + 1):
        if all(r in s for r in range(start, start + k)):
            yield start


def get_combo(cards, skip_pure_plane: bool = False) -> Combo | None:
    """识别一组牌的牌型; 非法返回 None。

    skip_pure_plane 用于"跟随飞机带翅膀"时的二次解析：同一组连续三张既可能是
    纯飞机也可能是飞机带单/带对，跟牌时要按上家的带翅膀牌型重新解读。
    """
    cards = list(cards)
    if not cards or len(set(cards)) != len(cards):
        return None
    if any((not isinstance(c, int)) or c < 0 or c > 53 for c in cards):
        return None
    rs = sorted(rank(c) for c in cards)
    n = len(rs)
    cnt = Counter(rs)
    uniq = sorted(cnt)
    key = tuple(sort_cards(cards))

    if n == 2 and set(rs) == {16, 17}:
        return Combo("rocket", 17, 1, key)
    if n == 4 and len(cnt) == 1:
        return Combo("bomb", uniq[0], 1, key)
    if n == 1:
        return Combo("single", uniq[0], 1, key)
    if n == 2 and len(cnt) == 1:
        return Combo("pair", uniq[0], 1, key)
    if n == 3 and len(cnt) == 1:
        return Combo("triple", uniq[0], 1, key)
    if n == 4 and sorted(cnt.values()) == [1, 3]:
        main = next(r for r, v in cnt.items() if v == 3)
        return Combo("triple1", main, 1, key)
    if n == 5 and sorted(cnt.values()) == [2, 3]:
        main = next(r for r, v in cnt.items() if v == 3)
        return Combo("triple2", main, 1, key)

    # 顺子
    if n >= 5 and len(cnt) == n and uniq[-1] <= 14 and uniq[-1] - uniq[0] == n - 1:
        return Combo("straight", uniq[0], n, key)

    # 连对
    if (n >= 6 and n % 2 == 0 and len(cnt) >= 3
            and all(v == 2 for v in cnt.values())
            and uniq[-1] <= 14 and uniq[-1] - uniq[0] == len(uniq) - 1):
        return Combo("pair_straight", uniq[0], len(uniq), key)

    # 纯飞机
    if (not skip_pure_plane and n >= 6 and n % 3 == 0 and len(cnt) >= 2
            and all(v == 3 for v in cnt.values())
            and uniq[-1] <= 14 and uniq[-1] - uniq[0] == len(uniq) - 1):
        return Combo("plane", uniq[0], len(uniq), key)

    # 飞机带单 / 带对
    triples = [r for r, v in cnt.items() if v == 3]
    if n % 4 == 0:
        k = n // 4
        if k >= 2:
            for start in _runs_of(triples, k):
                run = set(range(start, start + k))
                outside = sum(v for r, v in cnt.items() if r not in run)
                if outside == k:
                    return Combo("plane1", start, k, key)
    if n % 5 == 0:
        k = n // 5
        if k >= 2:
            for start in _runs_of(triples, k):
                run = set(range(start, start + k))
                rest = {r: v for r, v in cnt.items() if r not in run}
                if len(rest) == k and all(v == 2 for v in rest.values()):
                    return Combo("plane2", start, k, key)

    # 四带二 / 四带两对
    fours = [r for r, v in cnt.items() if v == 4]
    if n == 6 and len(fours) == 1:
        four = fours[0]
        if sum(v for r, v in cnt.items() if r != four) == 2:
            return Combo("four2", four, 1, key)
    if n == 8 and len(fours) == 1:
        four = fours[0]
        rest = {r: v for r, v in cnt.items() if r != four}
        if len(rest) == 2 and all(v == 2 for v in rest.values()):
            return Combo("four2pair", four, 1, key)

    return None


def can_beat(new: Combo, old: Combo | None) -> bool:
    if old is None:
        return True
    if new.type == "rocket":
        return old.type != "rocket"
    if old.type == "rocket":
        return False
    if new.type == "bomb":
        if old.type != "bomb":
            return True
        return new.main > old.main
    if old.type == "bomb":
        return False
    return (new.type == old.type and new.length == old.length
            and new.main > old.main)


def combo_name(cards) -> str:
    c = get_combo(cards)
    return c.label if c else "不符合任何牌型"


def _sort_play(p: tuple[int, ...]):
    return (len(p), tuple(rank(c) for c in p), p)


class PlayGen:
    """从一手牌生成所有合法候选出牌。"""

    def __init__(self, hand):
        self.cards = sort_cards(hand)
        self.by_rank: dict[int, list[int]] = {}
        for c in self.cards:
            self.by_rank.setdefault(rank(c), []).append(c)
        self.counts = {r: len(v) for r, v in self.by_rank.items()}
        self.rank_list = sorted(self.counts)
        self.plays: set[tuple[int, ...]] = set()

    # ---------- helpers ----------

    def _make(self, rc: dict[int, int]) -> tuple[int, ...] | None:
        out = []
        for r, n in sorted(rc.items()):
            pool = self.by_rank.get(r)
            if not pool or len(pool) < n:
                return None
            out.extend(pool[:n])
        return tuple(sort_cards(out))

    def _add(self, rc: dict[int, int]):
        p = self._make(rc)
        if p:
            self.plays.add(p)

    def _sequences(self, need: int, min_len: int, fixed_len: int | None = None,
                   min_start: int = 3):
        for start in range(3, 15):
            if self.counts.get(start, 0) < need:
                continue
            maxlen = 0
            while start + maxlen <= 14 and self.counts.get(start + maxlen, 0) >= need:
                maxlen += 1
            if fixed_len is not None:
                lengths = [fixed_len] if fixed_len <= maxlen else []
            else:
                lengths = range(min_len, maxlen + 1)
            if start < min_start:
                continue
            for L in lengths:
                yield start, L

    def _choose(self, avail: dict[int, int], k: int, limit: int = 120):
        ranks = sorted(r for r, n in avail.items() if n > 0)
        out = []
        for combo in combinations_with_replacement(ranks, k):
            c = Counter(combo)
            if all(c[r] <= avail[r] for r in c):
                out.append(c)
        out.sort(key=lambda c: (sum(r * n for r, n in c.items()),
                                tuple(sorted(c.elements()))))
        return out[:limit]

    # ---------- per-type generation ----------

    def gen_core(self, max_main: int | None = None, fixed_len: int | None = None,
                 only_type: str | None = None):
        """基础牌型; 供全量生成与跟牌共用。"""
        c = self.counts
        ot = only_type

        if ot in (None, "single"):
            for r in self.rank_list:
                if max_main is None or r > max_main:
                    self._add({r: 1})
        if ot in (None, "pair"):
            for r in self.rank_list:
                if c[r] >= 2 and (max_main is None or r > max_main):
                    self._add({r: 2})
        if ot in (None, "triple"):
            for r in self.rank_list:
                if c[r] >= 3 and (max_main is None or r > max_main):
                    self._add({r: 3})
        if ot in (None, "bomb"):
            for r in self.rank_list:
                if c[r] == 4 and (max_main is None or r > max_main):
                    self._add({r: 4})
            if 16 in c and 17 in c:
                self._add({16: 1, 17: 1})
        if ot in (None, "triple1"):
            for t in self.rank_list:
                if c[t] < 3 or (max_main is not None and t <= max_main):
                    continue
                for k in self.rank_list:
                    if k == t:
                        continue
                    self._add({t: 3, k: 1})
        if ot in (None, "triple2"):
            for t in self.rank_list:
                if c[t] < 3 or (max_main is not None and t <= max_main):
                    continue
                for p in self.rank_list:
                    if p != t and c[p] >= 2:
                        self._add({t: 3, p: 2})
        if ot in (None, "straight"):
            for start, L in self._sequences(1, 5, fixed_len=fixed_len,
                                            min_start=(max_main + 1) if max_main is not None else 3):
                self._add({r: 1 for r in range(start, start + L)})
        if ot in (None, "pair_straight"):
            for start, L in self._sequences(2, 3, fixed_len=fixed_len,
                                            min_start=(max_main + 1) if max_main is not None else 3):
                self._add({r: 2 for r in range(start, start + L)})
        if ot in (None, "plane"):
            for start, L in self._sequences(3, 2, fixed_len=fixed_len,
                                            min_start=(max_main + 1) if max_main is not None else 3):
                self._add({r: 3 for r in range(start, start + L)})

    def gen_winged(self, limit_per: int = 70):
        c = self.counts
        triples = [r for r in self.rank_list if c[r] >= 3]

        # 三带一 / 三带二
        for t in triples:
            for k in self.rank_list:
                if k != t:
                    self._add({t: 3, k: 1})
            for p in self.rank_list:
                if p != t and c[p] >= 2:
                    self._add({t: 3, p: 2})

        # 飞机带单
        for start, L in self._sequences(3, 2):
            run = list(range(start, start + L))
            avail = {r: n for r, n in c.items() if r not in run}
            for wings in self._choose(avail, L, limit=limit_per):
                rc = {r: 3 for r in run}
                for r, n in wings.items():
                    rc[r] = rc.get(r, 0) + n
                self._add(rc)

        # 飞机带对
        for start, L in self._sequences(3, 2):
            run = list(range(start, start + L))
            pair_ranks = [r for r in self.rank_list if r not in run and c[r] >= 2]
            for pairs in combinations(pair_ranks, L):
                rc = {r: 3 for r in run}
                for p in pairs:
                    rc[p] = 2
                self._add(rc)

        # 四带二单 / 四带两对
        for f in [r for r in self.rank_list if c[r] == 4]:
            avail = {r: n for r, n in c.items() if r != f}
            for wings in self._choose(avail, 2, limit=limit_per):
                rc = {f: 4}
                for r, n in wings.items():
                    rc[r] = rc.get(r, 0) + n
                self._add(rc)
            pair_ranks = [r for r in self.rank_list if r != f and c[r] >= 2]
            for pairs in combinations(pair_ranks, 2):
                rc = {f: 4, pairs[0]: 2, pairs[1]: 2}
                self._add(rc)

    def all(self, cap: int = 700) -> list[list[int]]:
        self.plays.clear()
        self.gen_core()
        core = set(self.plays)
        self.plays.clear()
        self.gen_winged()
        winged = sorted(self.plays - core, key=_sort_play)
        room = max(0, cap - len(core))
        combined = core | set(winged[:room])
        plays = [list(p) for p in combined]
        plays.sort(key=lambda p: (len(p), tuple(rank(c) for c in p)))
        return plays

    def beats(self, target: Combo, cap: int = 700) -> list[list[int]]:
        """跟牌候选; 包含空列表表示不出。"""
        self.plays.clear()
        if target.type == "rocket":
            return [[]]
        if target.type == "bomb":
            self.gen_core(max_main=target.main, only_type="bomb")
        else:
            self.gen_core(max_main=target.main, fixed_len=target.length,
                          only_type=target.type)
            self.gen_core(only_type="bomb")
        if target.type not in ("bomb", "rocket"):
            # 带牌类只能按指定长度/主牌重新生成
            if target.type in ("triple1", "triple2"):
                t = target.main
                c = self.counts
                if c.get(t, 0) >= 3:
                    if target.type == "triple1":
                        for k in self.rank_list:
                            if k != t:
                                self._add({t: 3, k: 1})
                    else:
                        for p in self.rank_list:
                            if p != t and c[p] >= 2:
                                self._add({t: 3, p: 2})
            elif target.type in ("plane1", "plane2"):
                k = target.length
                for start in range(target.main + 1, 15 - k + 1):
                    if all(self.counts.get(r, 0) >= 3 for r in range(start, start + k)):
                        run = list(range(start, start + k))
                        if target.type == "plane1":
                            avail = {r: n for r, n in self.counts.items() if r not in run}
                            for wings in self._choose(avail, k, limit=60):
                                rc = {r: 3 for r in run}
                                for r, n in wings.items():
                                    rc[r] = rc.get(r, 0) + n
                                self._add(rc)
                        else:
                            pair_ranks = [r for r in self.rank_list if r not in run and self.counts[r] >= 2]
                            for pairs in combinations(pair_ranks, k):
                                rc = {r: 3 for r in run}
                                for p in pairs:
                                    rc[p] = 2
                                self._add(rc)
            elif target.type in ("four2", "four2pair"):
                for f in self.rank_list:
                    if f <= target.main or self.counts.get(f, 0) != 4:
                        continue
                    avail = {r: n for r, n in self.counts.items() if r != f}
                    if target.type == "four2":
                        for wings in self._choose(avail, 2, limit=60):
                            rc = {f: 4}
                            for r, n in wings.items():
                                rc[r] = rc.get(r, 0) + n
                            self._add(rc)
                    else:
                        pair_ranks = [r for r in self.rank_list if r != f and self.counts[r] >= 2]
                        for pairs in combinations(pair_ranks, 2):
                            self._add({f: 4, pairs[0]: 2, pairs[1]: 2})
        # 用统一识别器过滤, 保证规则一致
        out = []
        for p in self.plays:
            cmb = get_combo(list(p))
            if cmb and can_beat(cmb, target):
                out.append(list(p))
        out.sort(key=lambda p: (len(p), tuple(rank(c) for c in p)))
        out = out[:cap]
        out.append([])  # 可以不出
        return out


def deduce(hand, cards, target: Combo | None) -> tuple[bool, str, Combo | None]:
    """校验一次出牌。"""
    cards = list(cards)
    if not cards:
        return False, "请选择要出的牌", None
    hand_set = set(hand)
    if len(set(cards)) != len(cards) or any(c not in hand_set for c in cards):
        return False, "手牌中没有这些牌", None
    cmb = get_combo(cards)
    if not cmb:
        return False, "这组牌不符合任何牌型", None
    if target is not None and not can_beat(cmb, target):
        # 连续三张既像纯飞机又像飞机带翅膀：跟 plane1/plane2 时按带翅膀重新解读，
        # 否则会把合法的"飞机带单/带对"压牌误判为打不过。
        if cmb.type == "plane" and target.type in ("plane1", "plane2"):
            alt = get_combo(cards, skip_pure_plane=True)
            if alt is not None and alt.type == target.type and can_beat(alt, target):
                return True, "", alt
        return False, f"打不过上家的{target.label}", None
    return True, "", cmb
