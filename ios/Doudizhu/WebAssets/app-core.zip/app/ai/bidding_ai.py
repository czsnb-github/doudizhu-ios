"""用 DouZero-WP 估值的叫地主 / 抢地主策略（不训练）。

思路：叫地主时不知道底牌，就从“我手里的 17 张”出发，按均匀先验采样
若干种底牌，补成 20 张地主手牌，用 WP 网络评估开局价值 v∈[-1,1]
（+1 稳赢，-1 稳输）。v ≥ 0 才叫地主；抢地主门槛更高，因为要主动
把倍数翻倍。出牌由 DouZero 端到端完成，叫/抢属于轻量估值层。

2026-10-27 的离线对比（1/2/3 叫分制，三个座位各 2500 局）显示价值
估值比规则估值平均每局多得约 24 分；改成“叫地主/不叫”后仍沿用同一
套 WP 估值，门槛按新规则重新定过。
"""

from __future__ import annotations

import random
import statistics

from ..cards import FULL_DECK, sort_cards
from ..game.engine import Game
from .agent import ai
from .bidding import JITTER, hand_strength


DEFAULT_CALL_TAU = 0.0   # 叫地主：WP 估值 ≥ 0 才叫
DEFAULT_SAMPLES = 6


def _start_state(hands, bottom, landlord: int) -> Game:
    """构造一个“刚叫完地主、准备出第一手”的假想局面。"""
    g = Game()
    g.phase = "playing"
    g.landlord = landlord
    g.current = landlord
    g.bottom_revealed = True
    g.bottom = list(bottom)
    g.hands = [sort_cards(list(h)) for h in hands]
    g.hands[landlord] = sort_cards(g.hands[landlord] + list(bottom))
    g.played = [[], [], []]
    g.last_action = [[], [], []]
    g.last_combo = None
    g.last_combo_cards = []
    g.last_play_seat = None
    g.passes = 0
    g.action_seq = []
    g.bomb_count = 0
    g.landlord_plays = 0
    g.farmer_plays = 0
    g.result = None
    g.multiplier = 1
    g.seq = 0
    g.event = None
    g.highlight = None
    return g


def _sample_deal(hand, seat: int, rng: random.Random):
    """只基于自己的手牌采样：3 张底牌 + 两个对手各 17 张。"""
    mine = list(hand)
    unseen = [c for c in FULL_DECK if c not in set(mine)]
    rng.shuffle(unseen)
    bottom = unseen[:3]
    rest = unseen[3:]
    others = [s for s in range(3) if s != seat]
    hands = [None, None, None]
    hands[seat] = mine
    hands[others[0]] = rest[:17]
    hands[others[1]] = rest[17:]
    return hands, bottom


class ValueBidder:
    """价值评估叫地主器；value_fn(game, seat) 默认走 DouZero-WP。"""

    def __init__(self, threshold: float = DEFAULT_CALL_TAU,
                 samples: int = DEFAULT_SAMPLES, value_fn=None,
                 seed: int | None = None):
        self.tau = float(threshold)
        self.samples = max(1, int(samples))
        self.value_fn = value_fn or ai.win_value
        self.rng = random.Random(seed)

    def landlord_value(self, hand, seat: int) -> float:
        vals = []
        for _ in range(self.samples):
            hands, bottom = _sample_deal(hand, seat, self.rng)
            g = _start_state(hands, bottom, seat)
            vals.append(float(self.value_fn(g, seat)))
        return statistics.mean(vals) if vals else 0.0

    def should_call(self, hand, seat: int) -> bool:
        """是否叫地主。没有底牌信息时，只有估值不亏才开口。"""
        return self.landlord_value(hand, seat) >= self.tau


def evaluate_is_last(hand, seat: int, rng: random.Random, samples: int = DEFAULT_SAMPLES) -> float:
    """辅助：给离线实验算一下单手的开局价值。"""
    vals = []
    for _ in range(samples):
        hands, bottom = _sample_deal(hand, seat, rng)
        g = _start_state(hands, bottom, seat)
        vals.append(float(ai.win_value(g, seat)))
    return statistics.mean(vals) if vals else 0.0


# 抢地主门槛：价值越高越敢抢。别人抢过之后叫地主者再“抢回”时，
# 对方已经用行动透露了强牌，所以门槛略高一点。
GRAB_TAU = 0.10
GRAB_TAU_REBACK = 0.15
GRAB_STRENGTH = {"easy": 12.0, "normal": 10.5}
GRAB_STRENGTH_REBACK = {"easy": 13.0, "normal": 11.5}


def grab_decision(hand, seat: int, level: str = "normal", value: float | None = None,
                  reback: bool = False, rng: random.Random | None = None) -> bool:
    """是否抢地主。困难/大师用 DouZero-WP 开局价值，简单/普通用牌力粗估。"""
    if level in ("hard", "master"):
        if value is None:
            return False
        tau = GRAB_TAU_REBACK if reback else GRAB_TAU
        return value >= tau
    strength = hand_strength(hand)
    base = (GRAB_STRENGTH_REBACK if reback else GRAB_STRENGTH).get(level, 10.5)
    if strength < base:
        return False
    if level == "easy":
        rng = rng or random
        return rng.random() >= (0.5 if reback else 0.45)
    return True


# 简单/普通难度的叫地主门槛：沿用旧规则叫分时“1 分”附近的牌力，
# 最后一家且两家都不叫时略放宽，避免一直重发。
CALL_STRENGTH = {"easy": 10.5, "normal": 9.0}
LAST_CALL_FLOOR = 8.0
LAST_CALL_CHANCE = 0.7


def choose_call(hand, level: str = "normal", is_last: bool = False,
                rng: random.Random | None = None) -> bool:
    """轻量规则叫地主：牌力够就叫；最后一家略放宽。"""
    rng = rng or random
    est = hand_strength(hand) + rng.uniform(
        -JITTER.get(level, 0.75), JITTER.get(level, 0.75)
    )
    if est >= CALL_STRENGTH.get(level, 9.0):
        return True
    if is_last and est >= LAST_CALL_FLOOR and rng.random() < LAST_CALL_CHANCE:
        return True
    return False
