"""机器人牌力估值（轻量规则）。

出牌由 DouZero 深度网络负责；叫地主/抢地主的简单档位用这里的牌力粗估。
"""

from __future__ import annotations

from collections import Counter

from ..cards import rank


def _longest_run(ranks: set[int]) -> int:
    best = cur = 0
    for r in range(3, 15):
        if r in ranks:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best


def hand_strength(hand) -> float:
    cnt = Counter(rank(c) for c in hand)
    s = 0.0
    if 17 in cnt:
        s += 4.0
    if 16 in cnt:
        s += 3.0
    if 16 in cnt and 17 in cnt:
        s += 2.0
    s += cnt.get(15, 0) * 1.8
    s += cnt.get(14, 0) * 1.0
    s += cnt.get(13, 0) * 0.4
    for r, n in cnt.items():
        if n == 4:
            s += 5.0 + (0.8 if r == 15 else 0.0)
        elif n == 3:
            s += 0.9
        elif n == 2:
            s += 0.25
    singles = {r for r, n in cnt.items() if n >= 1 and r <= 14}
    pairs = {r for r, n in cnt.items() if n >= 2 and r <= 14}
    s += max(0, _longest_run(singles) - 3) * 0.45
    s += max(0, _longest_run(pairs) - 2) * 0.55
    return s


JITTER = {"easy": 1.2, "normal": 0.75, "hard": 0.5, "master": 0.3}
