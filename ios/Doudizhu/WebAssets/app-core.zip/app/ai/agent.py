"""出牌 AI: DouZero 深度强化学习策略网络 + 难度分层。

- easy   : 监督学习模型 SL, 高温采样 + 探索
- normal : DouZero-ADP (分数目标), 轻采样
- hard   : DouZero-WP (胜率目标), 贪心
- master : DouZero-WP + DouZero-ADP 双模型集成, 贪心

模型来自 Kuaishou/Texas A&M 的 DouZero (ICML 2021, Apache-2.0)。
"""

from __future__ import annotations

import logging
import random
import sys
import threading
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
VENDOR = ROOT / "vendor"
if str(VENDOR) not in sys.path:
    sys.path.insert(0, str(VENDOR))

log = logging.getLogger(__name__)

MODEL_DIR = ROOT / "models"
LEVEL_MAIN = {
    "easy": "sl",
    "normal": "douzero_ADP",
    "hard": "douzero_WP",
    "master": "douzero_WP",
    # 隐藏档位：只给离线评测用，验证通过后才考虑暴露到 UI
    "ft": "douzero_FT",
}
LEVEL_TEMP = {"easy": 1.55, "normal": 0.8}
LEVEL_EPS = {"easy": 0.10, "normal": 0.025}


class DouZeroAI:
    def __init__(self):
        self._models: dict[tuple[str, str], object] = {}
        self._lock = threading.Lock()
        self._rng = random.Random()
        self.device = "cpu"
        self.available = False
        self.error = ""
        if sys.platform == "emscripten":
            self.error = "Pyodide 使用端侧 NumPy DouZero"
            return
        try:
            import torch  # noqa: F401
            from douzero.dmc.models import model_dict  # noqa: F401
            from douzero.env.env import get_obs  # noqa: F401
            self._torch = torch
            self._model_dict = model_dict
            self._get_obs = get_obs
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
            self.available = True
            log.info("DouZero loaded, device=%s", self.device)
        except Exception as exc:  # pragma: no cover
            self.error = str(exc)
            log.exception("DouZero 初始化失败, 将使用兜底策略")

    # ---------------------------------------------------------------- model

    def _get_model(self, model_name: str, position: str):
        key = (model_name, position)
        model = self._models.get(key)
        if model is not None:
            return model
        path = MODEL_DIR / model_name / f"{position}.ckpt"
        if not path.exists():
            raise FileNotFoundError(path)
        model = self._model_dict[position]().to(self.device)
        state = self._torch.load(path, map_location=self.device, weights_only=True)
        model.load_state_dict(state)
        model.eval()
        self._models[key] = model
        return model

    def warmup(self):
        if not self.available:
            return
        try:
            with self._lock:
                for model_name in ("sl", "douzero_ADP", "douzero_WP"):
                    for position in ("landlord", "landlord_up", "landlord_down"):
                        self._get_model(model_name, position)
            log.info("DouZero 全部模型已预载 (%s)", self.device)
        except Exception:
            log.exception("模型预载失败")

    def _values(self, model_name: str, infoset) -> np.ndarray:
        obs = self._get_obs(infoset)
        z = self._torch.from_numpy(obs["z_batch"]).float().to(self.device)
        x = self._torch.from_numpy(obs["x_batch"]).float().to(self.device)
        model = self._get_model(model_name, infoset.player_position)
        with self._torch.inference_mode():
            v = model(z, x, return_value=True)["values"]
        return v.detach().float().cpu().numpy().reshape(-1)

    def win_value(self, game, seat: int) -> float:
        """评估一个开局局面对 seat 所在阵营的价值。

        DouZero-WP 输出在 [-1, 1]：+1 稳赢、-1 稳输、0 五五开。
        取所有合法动作里的最大值，近似该局面的最优价值。
        对地主求值最可靠；农民的胜率可以用 -地主价值 得到。
        """
        if not self.available:
            return 0.0
        try:
            infoset = game.ai_input(seat)
            if not infoset.legal_actions:
                return 0.0
            with self._lock:
                values = self._values("douzero_WP", infoset)
            if len(values) == 0:
                return 0.0
            return float(np.max(values))
        except Exception:
            log.exception("开局胜率评估失败")
            return 0.0

    # ---------------------------------------------------------------- choose

    def choose(self, game, seat: int, level: str) -> list[int]:
        infoset = game.ai_input(seat)
        physical = infoset.physical_actions
        if len(physical) <= 1:
            return physical[0] if physical else []
        if not self.available:
            return self._fallback(infoset)

        level = level if level in LEVEL_MAIN else "normal"
        try:
            with self._lock:
                values = self._values(LEVEL_MAIN[level], infoset)
                if level == "master":
                    # 双模型集成: 胜率模型为主, 分数模型校正冒险倾向
                    v2 = self._values("douzero_ADP", infoset)
                    values = 0.62 * values + 0.38 * v2
        except Exception:
            log.exception("AI 推理失败, 使用兜底策略")
            return self._fallback(infoset)

        n = min(len(values), len(physical))
        if n <= 0:
            return self._fallback(infoset)
        values = values[:n]
        if level in ("hard", "master", "ft"):
            idx = int(np.argmax(values))
        else:
            temp = LEVEL_TEMP.get(level, 0.8)
            eps = LEVEL_EPS.get(level, 0.03)
            if self._rng.random() < eps:
                idx = self._rng.randrange(n)
            else:
                logits = (values - float(np.max(values))) / temp
                probs = np.exp(logits)
                probs /= probs.sum()
                idx = int(self._rng.choices(range(n), weights=probs.tolist())[0])
        return physical[idx]

    @staticmethod
    def _fallback(infoset) -> list[int]:
        """模型不可用时也要出牌；跟牌选最小合法一手，不能跟才过。"""
        actions = [p for p in infoset.physical_actions if p]
        if not actions:
            return []
        return min(actions, key=lambda p: (len(p), sum(p)))


ai = DouZeroAI()
