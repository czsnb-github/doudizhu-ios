"""运行期路径：数据目录与静态目录可用环境变量指向别处。

- DOUDIZHU_DATA_DIR   ：玩家档案、牌桌快照所在目录（默认 data/）
- DOUDIZHU_STATIC_DIR ：前端静态文件目录（默认 static/）

这样同一份代码可以另起一个隔离的 dev 实例，不碰正在玩的牌桌。
"""

from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _dir_from_env(name: str, default: Path) -> Path:
    raw = os.environ.get(name)
    if not raw:
        return default
    path = Path(raw).expanduser()
    if not path.is_absolute():
        path = ROOT / path
    return path


DATA_DIR = _dir_from_env("DOUDIZHU_DATA_DIR", ROOT / "data")
STATIC_DIR = _dir_from_env("DOUDIZHU_STATIC_DIR", ROOT / "static")
