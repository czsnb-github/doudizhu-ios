"""端侧 DouZero 推理（纯 NumPy）。

模型权重从 models/<set>/<position>.npz 读取；观测编码复用 vendor 里的 get_obs。
Pyodide 里没有 torch，这个模块提供和正式服 agent.py 相同的 choose/win_value 接口。
"""
from __future__ import annotations

import math
import os
import random
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
if not (ROOT / "vendor").exists():
    ROOT = ROOT.parent
VENDOR = ROOT / "vendor"
if str(VENDOR) not in sys.path:
    sys.path.insert(0, str(VENDOR))

from douzero.env.env import get_obs  # noqa: E402

H = 128
LEVEL_MODEL = {
    "easy": "douzero_ADP",
    "normal": "douzero_ADP",
    "hard": "douzero_WP",
    "master": "douzero_WP",
    "ft": "douzero_WP",
}
LEVEL_TEMP = {"easy": 1.55, "normal": 0.8}
LEVEL_EPS = {"easy": 0.10, "normal": 0.025}


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


class NumpyDouZeroAI:
    def __init__(self, model_dir: str | Path):
        self.model_dir = Path(model_dir)
        self._cache: dict[tuple[str, str], dict[str, np.ndarray]] = {}
        self._rng = random.Random()
        self.available = False
        self.error = ""
        try:
            probe = self._load("douzero_WP", "landlord")
            self.available = probe is not None
        except Exception as exc:
            self.error = str(exc)

    def _load(self, model_name: str, position: str) -> dict[str, np.ndarray]:
        key = (model_name, position)
        cached = self._cache.get(key)
        if cached is not None:
            return cached
        path = self.model_dir / model_name / f"{position}.npz"
        if not path.exists():
            raise FileNotFoundError(path)
        with np.load(path) as z:
            weights = {k: z[k].astype(np.float32) for k in z.files}
        self._cache[key] = weights
        return weights

    def _forward(self, z: np.ndarray, x: np.ndarray, model_name: str, position: str) -> np.ndarray:
        w = self._load(model_name, position)
        if z.ndim == 2:
            z = z[None, :, :]
        if x.ndim == 1:
            x = x[None, :]
        n = z.shape[0]
        h = np.zeros((n, H), dtype=np.float32)
        c = np.zeros((n, H), dtype=np.float32)
        xw = (
            z @ w["lstm.weight_ih_l0"].T
            + w["lstm.bias_ih_l0"]
            + w["lstm.bias_hh_l0"]
        )
        wh = w["lstm.weight_hh_l0"].T
        for t in range(z.shape[1]):
            gates = xw[:, t, :] + h @ wh
            i = _sigmoid(gates[:, :H])
            f = _sigmoid(gates[:, H:2 * H])
            g = np.tanh(gates[:, 2 * H:3 * H])
            o = _sigmoid(gates[:, 3 * H:])
            c = f * c + i * g
            h = o * np.tanh(c)
        u = np.concatenate([h, x], axis=1)
        for name in ("dense1", "dense2", "dense3", "dense4", "dense5"):
            u = np.maximum(u @ w[name + ".weight"].T + w[name + ".bias"], 0.0)
        v = u @ w["dense6.weight"].T + w["dense6.bias"]
        return v.reshape(-1)

    def _values(self, infoset, model_name: str) -> np.ndarray:
        obs = get_obs(infoset)
        return self._forward(
            np.asarray(obs["z_batch"], dtype=np.float32),
            np.asarray(obs["x_batch"], dtype=np.float32),
            model_name,
            infoset.player_position,
        )

    def win_value(self, game, seat: int) -> float:
        if not self.available:
            return 0.0
        try:
            infoset = game.ai_input(seat)
            if not infoset.legal_actions:
                return 0.0
            values = self._values(infoset, "douzero_WP")
            return float(np.max(values)) if len(values) else 0.0
        except Exception:
            return 0.0

    def choose(self, game, seat: int, level: str) -> list[int]:
        infoset = game.ai_input(seat)
        physical = infoset.physical_actions
        if len(physical) <= 1:
            return physical[0] if physical else []
        if not self.available:
            return self._fallback(infoset)
        level = level if level in LEVEL_MODEL else "normal"
        try:
            model_name = LEVEL_MODEL[level]
            values = self._values(infoset, model_name)
            if level == "master":
                try:
                    v2 = self._values(infoset, "douzero_ADP")
                    values = 0.62 * values + 0.38 * v2
                except Exception:
                    pass
        except Exception:
            return self._fallback(infoset)

        n = min(len(values), len(physical))
        if n <= 0:
            return self._fallback(infoset)
        values = values[:n]
        if level in ("hard", "master", "ft"):
            idx = int(np.argmax(values))
        else:
            temp = LEVEL_TEMP.get(level, 0.8)
            eps = LEVEL_EPS.get(level, 0.03)
            if self._rng.random() < eps:
                idx = self._rng.randrange(n)
            else:
                logits = (values - float(np.max(values))) / temp
                probs = np.exp(logits)
                probs /= probs.sum()
                idx = int(self._rng.choices(range(n), weights=probs.tolist())[0])
        return physical[idx]

    @staticmethod
    def _fallback(infoset) -> list[int]:
        actions = infoset.physical_actions
        if [] in actions:
            return []
        return min(actions, key=lambda p: (len(p), sum(p)))
